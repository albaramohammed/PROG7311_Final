﻿using MunicipalServicesApp2.Models;
using System;
using System.Collections.Generic;

namespace MunicipalServicesApp2.Utilities
{
    public class RequestHeap
    {
        private List<ServiceRequest> heap;

        public RequestHeap()
        {
            heap = new List<ServiceRequest>();
        }

        /// <summary>
        /// Gets the current size of the heap
        /// </summary>
        public int Count => heap.Count;

        /// <summary>
        /// Gets the parent index for a given node index
        /// </summary>
        private int GetParentIndex(int index) => (index - 1) / 2;

        /// <summary>
        /// Gets the left child index for a given node index
        /// </summary>
        private int GetLeftChildIndex(int index) => 2 * index + 1;

        /// <summary>
        /// Gets the right child index for a given node index
        /// </summary>
        private int GetRightChildIndex(int index) => 2 * index + 2;

        /// <summary>
        /// Adds a new service request to the heap
        /// </summary>
        public void Insert(ServiceRequest request)
        {
            heap.Add(request);
            HeapifyUp(heap.Count - 1);
        }

        /// <summary>
        /// Returns the highest priority request without removing it
        /// </summary>
        public ServiceRequest Peek()
        {
            if (heap.Count == 0)
                throw new InvalidOperationException("Heap is empty");
            return heap[0];
        }

        /// <summary>
        /// Removes and returns the highest priority request
        /// </summary>
        public ServiceRequest ExtractMax()
        {
            if (heap.Count == 0)
                throw new InvalidOperationException("Heap is empty");

            ServiceRequest max = heap[0];
            heap[0] = heap[heap.Count - 1];
            heap.RemoveAt(heap.Count - 1);

            if (heap.Count > 0)
                HeapifyDown(0);

            return max;
        }

        /// <summary>
        /// Updates a request's priority and adjusts its position
        /// </summary>
        public void UpdatePriority(ServiceRequest request)
        {
            int index = heap.FindIndex(r => r.Id == request.Id);
            if (index != -1)
            {
                heap[index] = request;
                HeapifyUp(index);
                HeapifyDown(index);
            }
        }

        /// <summary>
        /// Restores heap property by moving element up
        /// </summary>
        private void HeapifyUp(int index)
        {
            while (index > 0)
            {
                int parentIndex = GetParentIndex(index);
                if (GetPriority(heap[index]) <= GetPriority(heap[parentIndex]))
                    break;

                SwapRequests(index, parentIndex);
                index = parentIndex;
            }
        }

        /// <summary>
        /// Restores heap property by moving element down
        /// </summary>
        private void HeapifyDown(int index)
        {
            int maxIndex = index;
            int leftChild = GetLeftChildIndex(index);
            int rightChild = GetRightChildIndex(index);

            if (leftChild < heap.Count && GetPriority(heap[leftChild]) > GetPriority(heap[maxIndex]))
                maxIndex = leftChild;

            if (rightChild < heap.Count && GetPriority(heap[rightChild]) > GetPriority(heap[maxIndex]))
                maxIndex = rightChild;

            if (index != maxIndex)
            {
                SwapRequests(index, maxIndex);
                HeapifyDown(maxIndex);
            }
        }

        /// <summary>
        /// Swaps two requests in the heap
        /// </summary>
        private void SwapRequests(int i, int j)
        {
            ServiceRequest temp = heap[i];
            heap[i] = heap[j];
            heap[j] = temp;
        }

        /// <summary>
        /// Calculates priority based on request status and age
        /// </summary>
        private int GetPriority(ServiceRequest request)
        {
            int statusPriority = GetStatusPriority(request.Status);
            int agePriority = GetAgePriority(request.RequestDate);
            return statusPriority * 10 + agePriority;
        }

        /// <summary>
        /// Gets priority based on request status
        /// </summary>
        private int GetStatusPriority(string status)
        {
            switch (status.ToLower())
            {
                case "urgent": return 4;
                case "high": return 3;
                case "medium": return 2;
                case "low": return 1;
                default: return 0;
            }
        }

        /// <summary>
        /// Gets priority based on request age
        /// </summary>
        private int GetAgePriority(DateTime requestDate)
        {
            TimeSpan age = DateTime.Now - requestDate;
            if (age.TotalDays > 7) return 3;      // Older than a week
            if (age.TotalDays > 3) return 2;      // Older than 3 days
            if (age.TotalDays > 1) return 1;      // Older than 1 day
            return 0;                             // Less than 1 day old
        }

        /// <summary>
        /// Returns all requests in the heap without modifying it
        /// </summary>
        public List<ServiceRequest> GetAllRequests()
        {
            return new List<ServiceRequest>(heap);
        }

        /// <summary>
        /// Returns requests sorted by priority
        /// </summary>
        public List<ServiceRequest> GetAllRequestsSorted()
        {
            List<ServiceRequest> sorted = new List<ServiceRequest>();
            List<ServiceRequest> tempHeap = new List<ServiceRequest>(heap);

            while (heap.Count > 0)
            {
                sorted.Add(ExtractMax());
            }

            // Restore the heap
            heap = tempHeap;
            return sorted;
        }
    }
}