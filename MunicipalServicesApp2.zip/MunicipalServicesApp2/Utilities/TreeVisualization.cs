﻿using System;
using System.Collections.Generic;
using MunicipalServicesApp2.Models;

namespace MunicipalServicesApp2.Utilities
{
    public class TreeVisualization
    {
        // Node class for visualization
        public class TreeNodeVisual
        {
            public ServiceRequest Data { get; set; }
            public double X { get; set; }
            public double Y { get; set; }
            public TreeNodeVisual Left { get; set; }
            public TreeNodeVisual Right { get; set; }
            public TreeNodeVisual Parent { get; set; }
            public string NodeColor { get; set; }
            public int Level { get; set; }
            public bool IsRed { get; set; } // For Red-Black tree visualization
        }

        // Layout configuration
        private const double VerticalSpacing = 50;
        private const double HorizontalSpacing = 30;
        private double canvasWidth;
        private double canvasHeight;

        public TreeVisualization(double width, double height)
        {
            canvasWidth = width;
            canvasHeight = height;
        }

        // Calculate positions for tree nodes
        public void CalculateNodePositions(TreeNodeVisual root)
        {
            if (root == null) return;

            // Initialize levels dictionary to track node counts at each level
            var levels = new Dictionary<int, int>();
            CalculateLevels(root, 0, levels);

            // Calculate X and Y positions
            SetNodePositions(root, 0, 0, levels);
        }

        private void CalculateLevels(TreeNodeVisual node, int level, Dictionary<int, int> levels)
        {
            if (node == null) return;

            if (!levels.ContainsKey(level))
            {
                levels[level] = 0;
            }
            node.Level = level;
            levels[level]++;

            CalculateLevels(node.Left, level + 1, levels);
            CalculateLevels(node.Right, level + 1, levels);
        }

        private void SetNodePositions(TreeNodeVisual node, int level, int position, Dictionary<int, int> levels)
        {
            if (node == null) return;

            // Calculate Y position based on level
            node.Y = level * VerticalSpacing + 50;

            // Calculate X position
            double totalWidth = canvasWidth - 100; // Padding on both sides
            double nodesInLevel = levels[level];
            double spacing = totalWidth / (nodesInLevel + 1);
            node.X = (position + 1) * spacing + 50;

            // Process children
            if (node.Left != null)
            {
                SetNodePositions(node.Left, level + 1, position * 2, levels);
            }
            if (node.Right != null)
            {
                SetNodePositions(node.Right, level + 1, position * 2 + 1, levels);
            }
        }

        // Helper methods for tree conversion
        public static TreeNodeVisual ConvertToVisual<T>(TreeNode<T> node) where T : ServiceRequest
        {
            if (node == null) return null;

            var visual = new TreeNodeVisual
            {
                Data = node.Data,
                NodeColor = "Black", // Default color
                Level = 0
            };

            visual.Left = ConvertToVisual(node.Left);
            visual.Right = ConvertToVisual(node.Right);

            if (visual.Left != null) visual.Left.Parent = visual;
            if (visual.Right != null) visual.Right.Parent = visual;

            return visual;
        }

        // Get connections for drawing lines between nodes
        public List<(double X1, double Y1, double X2, double Y2)> GetConnections(TreeNodeVisual root)
        {
            var connections = new List<(double X1, double Y1, double X2, double Y2)>();
            AddConnections(root, connections);
            return connections;
        }

        private void AddConnections(TreeNodeVisual node, List<(double X1, double Y1, double X2, double Y2)> connections)
        {
            if (node == null) return;

            if (node.Left != null)
            {
                connections.Add((node.X, node.Y, node.Left.X, node.Left.Y));
                AddConnections(node.Left, connections);
            }

            if (node.Right != null)
            {
                connections.Add((node.X, node.Y, node.Right.X, node.Right.Y));
                AddConnections(node.Right, connections);
            }
        }
    }
}