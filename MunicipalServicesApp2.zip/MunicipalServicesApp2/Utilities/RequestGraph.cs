﻿using System;
using System.Collections.Generic;
using System.Linq;
using MunicipalServicesApp2.Models;
using MunicipalServicesApp2.Utilities;

namespace MunicipalServicesApp2.Utilities
{
    public class RequestGraph
    {
        private Dictionary<int, List<int>> adjacencyList;
        private Dictionary<int, ServiceRequest> requests;

        public RequestGraph()
        {
            adjacencyList = new Dictionary<int, List<int>>();
            requests = new Dictionary<int, ServiceRequest>();
        }

        /// <summary>
        /// Adds a service request to the graph
        /// </summary>
        public void AddRequest(ServiceRequest request)
        {
            if (!adjacencyList.ContainsKey(request.Id))
            {
                adjacencyList[request.Id] = new List<int>();
                requests[request.Id] = request;
            }
        }

        /// <summary>
        /// Updates an existing request in the graph
        /// </summary>
        public void UpdateRequest(ServiceRequest request)
        {
            if (requests.ContainsKey(request.Id))
            {
                requests[request.Id] = request;
            }
        }

        /// <summary>
        /// Adds a connection between two requests
        /// </summary>
        public void AddConnection(int request1Id, int request2Id)
        {
            if (!adjacencyList.ContainsKey(request1Id) || !adjacencyList.ContainsKey(request2Id))
                return;

            if (!adjacencyList[request1Id].Contains(request2Id))
                adjacencyList[request1Id].Add(request2Id);

            if (!adjacencyList[request2Id].Contains(request1Id))
                adjacencyList[request2Id].Add(request1Id);
        }

        /// <summary>
        /// Gets related requests for the given request ID
        /// </summary>
        public List<ServiceRequest> GetRelatedRequests(int requestId)
        {
            if (!adjacencyList.ContainsKey(requestId))
                return new List<ServiceRequest>();

            return adjacencyList[requestId]
                .Where(id => requests.ContainsKey(id))
                .Select(id => requests[id])
                .ToList();
        }

        /// <summary>
        /// Gets all requests in priority order
        /// </summary>
        public List<ServiceRequest> GetAllRequestsInPriorityOrder()
        {
            return requests.Values.OrderByDescending(r => GetPriorityValue(r)).ToList();
        }

        /// <summary>
        /// Gets nodes for visualization
        /// </summary>
        public List<GraphVisualization.Node> GetVisualizationNodes()
        {
            return requests.Values.Select(r => new GraphVisualization.Node
            {
                Id = r.Id,
                Label = r.Title,
                Status = r.Status,
                Request = r
            }).ToList();
        }

        /// <summary>
        /// Gets edges for visualization
        /// </summary>
        public List<GraphVisualization.Edge> GetVisualizationEdges()
        {
            var edges = new List<GraphVisualization.Edge>();
            foreach (var pair in adjacencyList)
            {
                foreach (var connectedId in pair.Value)
                {
                    if (pair.Key < connectedId) // Avoid duplicate edges
                    {
                        edges.Add(new GraphVisualization.Edge
                        {
                            FromId = pair.Key,
                            ToId = connectedId
                        });
                    }
                }
            }
            return edges;
        }

        /// <summary>
        /// Calculates the density of the graph
        /// </summary>
        public double CalculateDensity()
        {
            int vertices = requests.Count;
            if (vertices <= 1) return 0;

            int edges = adjacencyList.Sum(kvp => kvp.Value.Count) / 2; // Divide by 2 since edges are counted twice
            int maxPossibleEdges = (vertices * (vertices - 1)) / 2;

            return maxPossibleEdges > 0 ? (double)edges / maxPossibleEdges : 0;
        }

        /// <summary>
        /// Gets all requests in a category
        /// </summary>
        public List<ServiceRequest> GetRequestsByCategory(string category)
        {
            return requests.Values
                .Where(r => r.Category.Equals(category, StringComparison.OrdinalIgnoreCase))
                .ToList();
        }

        /// <summary>
        /// Gets all requests in a location
        /// </summary>
        public List<ServiceRequest> GetRequestsByLocation(string location)
        {
            return requests.Values
                .Where(r => r.Location.Equals(location, StringComparison.OrdinalIgnoreCase))
                .ToList();
        }

        /// <summary>
        /// Gets the shortest path between two requests
        /// </summary>
        public List<ServiceRequest> FindShortestPath(int startId, int endId)
        {
            if (!requests.ContainsKey(startId) || !requests.ContainsKey(endId))
                return new List<ServiceRequest>();

            var visited = new HashSet<int>();
            var previous = new Dictionary<int, int>();
            var queue = new Queue<int>();

            queue.Enqueue(startId);
            visited.Add(startId);

            while (queue.Count > 0)
            {
                int current = queue.Dequeue();
                if (current == endId)
                    break;

                foreach (int neighbor in adjacencyList[current])
                {
                    if (!visited.Contains(neighbor))
                    {
                        visited.Add(neighbor);
                        previous[neighbor] = current;
                        queue.Enqueue(neighbor);
                    }
                }
            }

            if (!visited.Contains(endId))
                return new List<ServiceRequest>();

            var path = new List<ServiceRequest>();
            int currentId = endId;
            while (currentId != startId)
            {
                path.Add(requests[currentId]);
                currentId = previous[currentId];
            }
            path.Add(requests[startId]);
            path.Reverse();

            return path;
        }

        private int GetPriorityValue(ServiceRequest request)
        {
            string priority = request.Priority.ToLower();
            switch (priority)
            {
                case "urgent": return 4;
                case "high": return 3;
                case "medium": return 2;
                case "low": return 1;
                default: return 0;
            }
        }
    }
}