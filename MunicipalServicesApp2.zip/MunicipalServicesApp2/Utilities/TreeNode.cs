﻿using System;

namespace MunicipalServicesApp2.Utilities
{
    public class TreeNode<T> where T : IComparable<T>
    {
        public T Data { get; set; }
        public TreeNode<T> Left { get; set; }
        public TreeNode<T> Right { get; set; }
        public TreeNode<T> Parent { get; set; }
        public int Height { get; set; }  // Will be useful for AVL trees later

        public TreeNode(T data)
        {
            Data = data;
            Left = null;
            Right = null;
            Parent = null;
            Height = 1;
        }

        // Helper method to compare nodes
        public int CompareTo(TreeNode<T> other)
        {
            if (other == null) return 1;
            return Data.CompareTo(other.Data);
        }

        // Helper method to get the balance factor (for AVL trees)
        public int GetBalanceFactor()
        {
            int leftHeight = Left?.Height ?? 0;
            int rightHeight = Right?.Height ?? 0;
            return leftHeight - rightHeight;
        }

        // Helper method to update height (for AVL trees)
        public void UpdateHeight()
        {
            int leftHeight = Left?.Height ?? 0;
            int rightHeight = Right?.Height ?? 0;
            Height = Math.Max(leftHeight, rightHeight) + 1;
        }

      

        public int GetHeight()
        {
            int leftHeight = Left?.Height ?? 0;
            int rightHeight = Right?.Height ?? 0;
            return Math.Max(leftHeight, rightHeight) + 1;
        }
    }
}