﻿using MunicipalServicesApp2.Models;
using System;
using System.Collections.Generic;

namespace MunicipalServicesApp2.Utilities
{
    public class RedBlackTree<T> where T : IComparable<T>
    {
        private enum NodeColor { Red, Black }

        private class RBNode
        {
            public T Data { get; set; }
            public RBNode Left { get; set; }
            public RBNode Right { get; set; }
            public RBNode Parent { get; set; }
            public NodeColor Color { get; set; }

            public RBNode(T data)
            {
                Data = data;
                Color = NodeColor.Red; // New nodes are always red
                Left = Right = Parent = null;
            }
        }

        private RBNode root;

        /// <summary>
        /// Inserts a new value into the Red-Black tree
        /// </summary>
        public void Insert(T data)
        {
            RBNode newNode = new RBNode(data);

            if (root == null)
            {
                root = newNode;
                root.Color = NodeColor.Black; // Root must be black
                return;
            }

            InsertRecursive(root, newNode);
            FixViolations(newNode);
        }

        /// <summary>
        /// Helper method for recursive insertion
        /// </summary>
        private void InsertRecursive(RBNode current, RBNode newNode)
        {
            if (newNode.Data.CompareTo(current.Data) < 0)
            {
                if (current.Left == null)
                {
                    current.Left = newNode;
                    newNode.Parent = current;
                }
                else
                    InsertRecursive(current.Left, newNode);
            }
            else
            {
                if (current.Right == null)
                {
                    current.Right = newNode;
                    newNode.Parent = current;
                }
                else
                    InsertRecursive(current.Right, newNode);
            }
        }

        /// <summary>
        /// Fixes Red-Black tree violations after insertion
        /// </summary>
        private void FixViolations(RBNode node)
        {
            while (node != root && node.Parent.Color == NodeColor.Red)
            {
                RBNode parent = node.Parent;
                RBNode grandparent = parent.Parent;

                if (grandparent == null)
                    break;

                if (parent == grandparent.Left)
                {
                    RBNode uncle = grandparent.Right;

                    if (uncle != null && uncle.Color == NodeColor.Red)
                    {
                        parent.Color = NodeColor.Black;
                        uncle.Color = NodeColor.Black;
                        grandparent.Color = NodeColor.Red;
                        node = grandparent;
                    }
                    else
                    {
                        if (node == parent.Right)
                        {
                            RotateLeft(parent);
                            node = parent;
                            parent = node.Parent;
                        }

                        parent.Color = NodeColor.Black;
                        grandparent.Color = NodeColor.Red;
                        RotateRight(grandparent);
                    }
                }
                else
                {
                    RBNode uncle = grandparent.Left;

                    if (uncle != null && uncle.Color == NodeColor.Red)
                    {
                        parent.Color = NodeColor.Black;
                        uncle.Color = NodeColor.Black;
                        grandparent.Color = NodeColor.Red;
                        node = grandparent;
                    }
                    else
                    {
                        if (node == parent.Left)
                        {
                            RotateRight(parent);
                            node = parent;
                            parent = node.Parent;
                        }

                        parent.Color = NodeColor.Black;
                        grandparent.Color = NodeColor.Red;
                        RotateLeft(grandparent);
                    }
                }
            }

            root.Color = NodeColor.Black;
        }

        /// <summary>
        /// Performs a left rotation
        /// </summary>
        private void RotateLeft(RBNode node)
        {
            RBNode rightChild = node.Right;
            node.Right = rightChild.Left;

            if (rightChild.Left != null)
                rightChild.Left.Parent = node;

            rightChild.Parent = node.Parent;

            if (node.Parent == null)
                root = rightChild;
            else if (node == node.Parent.Left)
                node.Parent.Left = rightChild;
            else
                node.Parent.Right = rightChild;

            rightChild.Left = node;
            node.Parent = rightChild;
        }

        /// <summary>
        /// Performs a right rotation
        /// </summary>
        private void RotateRight(RBNode node)
        {
            RBNode leftChild = node.Left;
            node.Left = leftChild.Right;

            if (leftChild.Right != null)
                leftChild.Right.Parent = node;

            leftChild.Parent = node.Parent;

            if (node.Parent == null)
                root = leftChild;
            else if (node == node.Parent.Right)
                node.Parent.Right = leftChild;
            else
                node.Parent.Left = leftChild;

            leftChild.Right = node;
            node.Parent = leftChild;
        }

        /// <summary>
        /// Returns all items in the tree in order
        /// </summary>
        public List<T> GetInOrderTraversal()
        {
            List<T> result = new List<T>();
            InOrderTraversal(root, result);
            return result;
        }

        private void InOrderTraversal(RBNode node, List<T> result)
        {
            if (node != null)
            {
                InOrderTraversal(node.Left, result);
                result.Add(node.Data);
                InOrderTraversal(node.Right, result);
            }
        }

        internal object Search(ServiceRequest request)
        {
            throw new NotImplementedException();
        }
    }
}