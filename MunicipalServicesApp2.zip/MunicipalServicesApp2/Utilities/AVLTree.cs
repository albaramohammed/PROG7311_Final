﻿using System;
using System.Collections.Generic;

namespace MunicipalServicesApp2.Utilities
{
    public class AVLTree<T> where T : IComparable<T>
    {
        private TreeNode<T> root;

        public AVLTree()
        {
            root = null;
        }
        /// <summary>
        /// Gets the height of the entire tree
        /// </summary>
        public int GetHeight()
        {
            return GetHeight(root);
        }
        /// <summary>
        /// Gets the height of a node
        /// </summary>

        /// <summary>
        /// Gets the root node of the tree
        /// </summary>
        public TreeNode<T> GetRoot()
        {
            return root;
        }
        public int GetHeight(TreeNode<T> node)
        {
            return node?.Height ?? 0;
        }

        /// <summary>
        /// Updates the height of a node
        /// </summary>
        public void UpdateHeight(TreeNode<T> node)
        {
            if (node != null)
                node.Height = 1 + Math.Max(GetHeight(node.Left), GetHeight(node.Right));
        }

        /// <summary>
        /// Gets the balance factor of a node
        /// </summary>
        private int GetBalanceFactor(TreeNode<T> node)
        {
            return node == null ? 0 : GetHeight(node.Left) - GetHeight(node.Right);
        }

        /// <summary>
        /// Performs a right rotation
        /// </summary>
        private TreeNode<T> RotateRight(TreeNode<T> y)
        {
            TreeNode<T> x = y.Left;
            TreeNode<T> T2 = x.Right;

            x.Right = y;
            y.Left = T2;

            if (T2 != null)
                T2.Parent = y;

            x.Parent = y.Parent;
            y.Parent = x;

            UpdateHeight(y);
            UpdateHeight(x);

            return x;
        }

        /// <summary>
        /// Performs a left rotation
        /// </summary>
        private TreeNode<T> RotateLeft(TreeNode<T> x)
        {
            TreeNode<T> y = x.Right;
            TreeNode<T> T2 = y.Left;

            y.Left = x;
            x.Right = T2;

            if (T2 != null)
                T2.Parent = x;

            y.Parent = x.Parent;
            x.Parent = y;

            UpdateHeight(x);
            UpdateHeight(y);

            return y;
        }

        /// <summary>
        /// Inserts a new value into the AVL tree
        /// </summary>
        public void Insert(T data)
        {
            root = InsertRecursive(root, null, data);
        }

        /// <summary>
        /// Helper method for recursive insertion
        /// </summary>
        private TreeNode<T> InsertRecursive(TreeNode<T> node, TreeNode<T> parent, T data)
        {
            if (node == null)
            {
                TreeNode<T> newNode = new TreeNode<T>(data) { Parent = parent };
                return newNode;
            }

            if (data.CompareTo(node.Data) < 0)
                node.Left = InsertRecursive(node.Left, node, data);
            else if (data.CompareTo(node.Data) > 0)
                node.Right = InsertRecursive(node.Right, node, data);
            else
                return node; // Duplicate values not allowed

            UpdateHeight(node);

            int balance = GetBalanceFactor(node);

            // Left Left Case
            if (balance > 1 && data.CompareTo(node.Left.Data) < 0)
                return RotateRight(node);

            // Right Right Case
            if (balance < -1 && data.CompareTo(node.Right.Data) > 0)
                return RotateLeft(node);

            // Left Right Case
            if (balance > 1 && data.CompareTo(node.Left.Data) > 0)
            {
                node.Left = RotateLeft(node.Left);
                return RotateRight(node);
            }

            // Right Left Case
            if (balance < -1 && data.CompareTo(node.Right.Data) < 0)
            {
                node.Right = RotateRight(node.Right);
                return RotateLeft(node);
            }

            return node;
        }

        /// <summary>
        /// Searches for a value in the tree
        /// </summary>
        public TreeNode<T> Search(T data)
        {
            return SearchRecursive(root, data);
        }

        /// <summary>
        /// Helper method for recursive search
        /// </summary>
        private TreeNode<T> SearchRecursive(TreeNode<T> node, T data)
        {
            if (node == null || data.CompareTo(node.Data) == 0)
                return node;

            if (data.CompareTo(node.Data) < 0)
                return SearchRecursive(node.Left, data);

            return SearchRecursive(node.Right, data);
        }

        /// <summary>
        /// Performs an in-order traversal of the tree
        /// </summary>
        public List<T> InOrderTraversal()
        {
            List<T> result = new List<T>();
            InOrderTraversalRecursive(root, result);
            return result;
        }

        /// <summary>
        /// Helper method for recursive in-order traversal
        /// </summary>
        private void InOrderTraversalRecursive(TreeNode<T> node, List<T> result)
        {
            if (node != null)
            {
                InOrderTraversalRecursive(node.Left, result);
                result.Add(node.Data);
                InOrderTraversalRecursive(node.Right, result);
            }
        }
    }
}