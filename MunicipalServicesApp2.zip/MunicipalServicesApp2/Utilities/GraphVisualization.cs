﻿using System;
using System.Collections.Generic;
using System.Linq;
using MunicipalServicesApp2.Models;

namespace MunicipalServicesApp2.Utilities
{
    public class GraphVisualization
    {
        // Node class for visualization
        public class Node
        {
            public int Id { get; set; }
            public string Label { get; set; }
            public double X { get; set; }
            public double Y { get; set; }
            public string Status { get; set; }
            public ServiceRequest Request { get; set; }
        }

        // Edge class for visualization
        public class Edge
        {
            public int FromId { get; set; }
            public int ToId { get; set; }
            public Node FromNode { get; set; }
            public Node ToNode { get; set; }
        }

        private double canvasWidth;
        private double canvasHeight;
        private const double NodeRadius = 20;

        public GraphVisualization(double width, double height)
        {
            canvasWidth = width;
            canvasHeight = height;
        }

        // Calculate positions for nodes in circular layout
        public void CalculateCircularLayout(List<Node> nodes)
        {
            if (nodes == null || nodes.Count == 0) return;

            double radius = Math.Min(canvasWidth, canvasHeight) * 0.35;
            double centerX = canvasWidth / 2;
            double centerY = canvasHeight / 2;

            for (int i = 0; i < nodes.Count; i++)
            {
                double angle = (2 * Math.PI * i) / nodes.Count;
                nodes[i].X = centerX + radius * Math.Cos(angle);
                nodes[i].Y = centerY + radius * Math.Sin(angle);
            }
        }

        // Calculate force-directed layout
        public void CalculateForceDirectedLayout(List<Node> nodes, List<Edge> edges, int iterations = 100)
        {
            if (nodes == null || nodes.Count == 0) return;

            // Initialize random positions
            Random random = new Random();
            foreach (var node in nodes)
            {
                node.X = random.NextDouble() * canvasWidth;
                node.Y = random.NextDouble() * canvasHeight;
            }

            double k = Math.Sqrt((canvasWidth * canvasHeight) / nodes.Count);
            double temperature = canvasWidth / 10;
            double minTemp = 1.0;

            for (int i = 0; i < iterations && temperature > minTemp; i++)
            {
                // Calculate repulsive forces
                foreach (var v1 in nodes)
                {
                    v1.X += random.NextDouble() * 0.1 - 0.05;
                    v1.Y += random.NextDouble() * 0.1 - 0.05;

                    foreach (var v2 in nodes)
                    {
                        if (v1 != v2)
                        {
                            double dx = v2.X - v1.X;
                            double dy = v2.Y - v1.Y;
                            double distance = Math.Sqrt(dx * dx + dy * dy);

                            if (distance > 0)
                            {
                                double repulsiveForce = k * k / distance;
                                v1.X -= dx / distance * repulsiveForce;
                                v1.Y -= dy / distance * repulsiveForce;
                            }
                        }
                    }
                }

                // Calculate attractive forces
                foreach (var edge in edges)
                {
                    var v1 = nodes.Find(n => n.Id == edge.FromId);
                    var v2 = nodes.Find(n => n.Id == edge.ToId);

                    if (v1 != null && v2 != null)
                    {
                        double dx = v2.X - v1.X;
                        double dy = v2.Y - v1.Y;
                        double distance = Math.Sqrt(dx * dx + dy * dy);

                        if (distance > 0)
                        {
                            double attractiveForce = distance * distance / k;
                            v1.X += dx / distance * attractiveForce;
                            v1.Y += dy / distance * attractiveForce;
                            v2.X -= dx / distance * attractiveForce;
                            v2.Y -= dy / distance * attractiveForce;
                        }
                    }
                }

                temperature *= 0.95;
            }

            // Normalize positions to fit canvas
            NormalizePositions(nodes);
        }

        private void NormalizePositions(List<Node> nodes)
        {
            double minX = nodes.Min(n => n.X);
            double maxX = nodes.Max(n => n.X);
            double minY = nodes.Min(n => n.Y);
            double maxY = nodes.Max(n => n.Y);

            double padding = NodeRadius * 2;
            double scaleX = (canvasWidth - padding * 2) / (maxX - minX);
            double scaleY = (canvasHeight - padding * 2) / (maxY - minY);
            double scale = Math.Min(scaleX, scaleY);

            foreach (var node in nodes)
            {
                node.X = (node.X - minX) * scale + padding;
                node.Y = (node.Y - minY) * scale + padding;
            }
        }

        // Convert ServiceRequest to Node
        public Node CreateNode(ServiceRequest request)
        {
            return new Node
            {
                Id = request.Id,
                Label = request.Title,
                Status = request.Status,
                Request = request
            };
        }

        // Create edge between nodes
        public Edge CreateEdge(int fromId, int toId)
        {
            return new Edge
            {
                FromId = fromId,
                ToId = toId
            };
        }
    }
}