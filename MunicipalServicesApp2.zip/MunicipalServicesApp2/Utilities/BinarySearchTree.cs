﻿using System;
using System.Collections.Generic;

namespace MunicipalServicesApp2.Utilities
{
    public class BinarySearchTree<T> where T : IComparable<T>
    {
        private TreeNode<T> root;

        public BinarySearchTree()
        {
            root = null;
        }

        /// <summary>
        /// Inserts a new value into the binary search tree
        /// </summary>
        public void Insert(T data)
        {
            TreeNode<T> newNode = new TreeNode<T>(data);
            if (root == null)
            {
                root = newNode;
                return;
            }

            InsertRecursive(root, newNode);
        }

        /// <summary>
        /// Helper method for recursive insertion
        /// </summary>
        private void InsertRecursive(TreeNode<T> current, TreeNode<T> newNode)
        {
            if (newNode.CompareTo(current) < 0)
            {
                if (current.Left == null)
                {
                    current.Left = newNode;
                    newNode.Parent = current;
                }
                else
                    InsertRecursive(current.Left, newNode);
            }
            else
            {
                if (current.Right == null)
                {
                    current.Right = newNode;
                    newNode.Parent = current;
                }
                else
                    InsertRecursive(current.Right, newNode);
            }
        }

        /// <summary>
        /// Searches for a value in the tree
        /// </summary>
        public TreeNode<T> Search(T data)
        {
            return SearchRecursive(root, data);
        }

        /// <summary>
        /// Helper method for recursive search
        /// </summary>
        private TreeNode<T> SearchRecursive(TreeNode<T> current, T data)
        {
            if (current == null || current.Data.CompareTo(data) == 0)
                return current;

            if (data.CompareTo(current.Data) < 0)
                return SearchRecursive(current.Left, data);

            return SearchRecursive(current.Right, data);
        }

        /// <summary>
        /// Performs an in-order traversal of the tree
        /// </summary>
        public List<T> InOrderTraversal()
        {
            List<T> result = new List<T>();
            InOrderTraversalRecursive(root, result);
            return result;
        }

        /// <summary>
        /// Helper method for recursive in-order traversal
        /// </summary>
        private void InOrderTraversalRecursive(TreeNode<T> node, List<T> result)
        {
            if (node != null)
            {
                InOrderTraversalRecursive(node.Left, result);
                result.Add(node.Data);
                InOrderTraversalRecursive(node.Right, result);
            }
        }

        /// <summary>
        /// Removes a value from the tree
        /// </summary>
        public bool Remove(T data)
        {
            TreeNode<T> nodeToRemove = Search(data);
            if (nodeToRemove == null)
                return false;

            return RemoveNode(nodeToRemove);
        }

        /// <summary>
        /// Helper method for removing a node
        /// </summary>
        private bool RemoveNode(TreeNode<T> nodeToRemove)
        {
            if (nodeToRemove == null) return false;

            TreeNode<T> parent = nodeToRemove.Parent;

            // Case 1: Node has no children
            if (nodeToRemove.Left == null && nodeToRemove.Right == null)
            {
                if (parent == null)
                    root = null;
                else if (parent.Left == nodeToRemove)
                    parent.Left = null;
                else
                    parent.Right = null;
            }
            // Case 2: Node has only right child
            else if (nodeToRemove.Left == null)
            {
                if (parent == null)
                    root = nodeToRemove.Right;
                else if (parent.Left == nodeToRemove)
                    parent.Left = nodeToRemove.Right;
                else
                    parent.Right = nodeToRemove.Right;
                nodeToRemove.Right.Parent = parent;
            }
            // Case 3: Node has only left child
            else if (nodeToRemove.Right == null)
            {
                if (parent == null)
                    root = nodeToRemove.Left;
                else if (parent.Left == nodeToRemove)
                    parent.Left = nodeToRemove.Left;
                else
                    parent.Right = nodeToRemove.Left;
                nodeToRemove.Left.Parent = parent;
            }
            // Case 4: Node has both children
            else
            {
                TreeNode<T> successor = FindMin(nodeToRemove.Right);
                nodeToRemove.Data = successor.Data;
                RemoveNode(successor);
            }

            return true;
        }

        /// <summary>
        /// Finds the minimum value in a subtree
        /// </summary>
        private TreeNode<T> FindMin(TreeNode<T> node)
        {
            while (node.Left != null)
                node = node.Left;
            return node;
        }
    }
}