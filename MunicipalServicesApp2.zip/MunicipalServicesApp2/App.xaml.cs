﻿using System.Windows;
using MunicipalServicesApp2.Services;

namespace MunicipalServicesApp2
{
    public partial class App : Application
    {
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            // Create service instances with fully qualified name for EventManager
            var eventManager = new MunicipalServicesApp2.Services.EventManager();
            var announcementManager = new AnnouncementManager();
            var issueManager = new IssueManager();
            var userEngagementService = new UserEngagementService();
            var searchEngine = new SearchEngine(eventManager);
            var serviceRequestManager = new ServiceRequestManager();

            // Create main window
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();

            // Initialize services
            mainWindow.InitializeServices(
                eventManager,
                announcementManager,
                issueManager,
                userEngagementService,
                searchEngine,
                serviceRequestManager);

            mainWindow.NavigateToMainMenu();
        }
    }
}