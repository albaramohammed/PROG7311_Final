﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using MunicipalServicesApp2.Models;
using MunicipalServicesApp2.Utilities;

namespace MunicipalServicesApp2.Controls
{
    public partial class GraphVisualizer : UserControl
    {
        private GraphVisualization graphViz;

        public static readonly DependencyProperty NodesProperty =
            DependencyProperty.Register("Nodes", typeof(ObservableCollection<GraphVisualization.Node>),
                typeof(GraphVisualizer), new PropertyMetadata(null, OnNodesChanged));

        public static readonly DependencyProperty EdgesProperty =
            DependencyProperty.Register("Edges", typeof(ObservableCollection<GraphVisualization.Edge>),
                typeof(GraphVisualizer), new PropertyMetadata(null, OnEdgesChanged));

        public ObservableCollection<GraphVisualization.Node> Nodes
        {
            get { return (ObservableCollection<GraphVisualization.Node>)GetValue(NodesProperty); }
            set { SetValue(NodesProperty, value); }
        }

        public ObservableCollection<GraphVisualization.Edge> Edges
        {
            get { return (ObservableCollection<GraphVisualization.Edge>)GetValue(EdgesProperty); }
            set { SetValue(EdgesProperty, value); }
        }

        public GraphVisualizer()
        {
            InitializeComponent();
            Loaded += GraphVisualizer_Loaded;

            // Initialize collections
            Nodes = new ObservableCollection<GraphVisualization.Node>();
            Edges = new ObservableCollection<GraphVisualization.Edge>();

            // Initialize the GraphVisualization with default size
            graphViz = new GraphVisualization(800, 450);
        }

        private void GraphVisualizer_Loaded(object sender, RoutedEventArgs e)
        {
            // Set up bindings
            NodeContainer.ItemsSource = Nodes;
            EdgeContainer.ItemsSource = Edges;

            // Update layout when control is loaded
            UpdateLayout();
        }

        private static void OnNodesChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as GraphVisualizer;
            if (control != null)
            {
                control.UpdateLayout();
            }
        }

        private static void OnEdgesChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as GraphVisualizer;
            if (control != null)
            {
                control.UpdateLayout();
            }
        }

        public void UpdateLayout()
        {
            if (Nodes == null || Nodes.Count == 0) return;

            // Update the GraphVisualization dimensions based on actual control size
            graphViz = new GraphVisualization(ActualWidth > 0 ? ActualWidth : 800,
                                            ActualHeight > 0 ? ActualHeight : 450);

            // Calculate layout
            var nodesList = new List<GraphVisualization.Node>(Nodes);
            var edgesList = new List<GraphVisualization.Edge>(Edges);

            // Use force-directed layout for more than 3 nodes, otherwise use circular
            if (nodesList.Count > 3)
            {
                graphViz.CalculateForceDirectedLayout(nodesList, edgesList);
            }
            else
            {
                graphViz.CalculateCircularLayout(nodesList);
            }

            // Update node positions
            Nodes.Clear();
            foreach (var node in nodesList)
            {
                Nodes.Add(node);
            }

            // Update edge positions
            Edges.Clear();
            foreach (var edge in edgesList)
            {
                edge.FromNode = Nodes[nodesList.FindIndex(n => n.Id == edge.FromId)];
                edge.ToNode = Nodes[nodesList.FindIndex(n => n.Id == edge.ToId)];
                Edges.Add(edge);
            }
        }

        public void AddNode(ServiceRequest request)
        {
            var node = graphViz.CreateNode(request);
            Nodes.Add(node);
            UpdateLayout();
        }

        public void AddEdge(int fromId, int toId)
        {
            var edge = graphViz.CreateEdge(fromId, toId);
            Edges.Add(edge);
            UpdateLayout();
        }

        public void Clear()
        {
            Nodes.Clear();
            Edges.Clear();
        }
    }
}