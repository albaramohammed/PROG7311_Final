﻿using System.Windows;
using System.Windows.Controls;
using MunicipalServicesApp2.Utilities;

namespace MunicipalServicesApp2.Controls
{
    public partial class TreeVisualizer : UserControl
    {
        public static readonly DependencyProperty RootProperty =
            DependencyProperty.Register(
                "Root",
                typeof(TreeVisualization.TreeNodeVisual),
                typeof(TreeVisualizer),
                new PropertyMetadata(null, OnRootChanged));

        public TreeVisualization.TreeNodeVisual Root
        {
            get { return (TreeVisualization.TreeNodeVisual)GetValue(RootProperty); }
            set { SetValue(RootProperty, value); }
        }

        public TreeVisualizer()
        {
            InitializeComponent();
            this.Loaded += TreeVisualizer_Loaded;
        }

        private void TreeVisualizer_Loaded(object sender, RoutedEventArgs e)
        {
            UpdateVisualization();
        }

        private static void OnRootChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as TreeVisualizer;
            control?.UpdateVisualization();
        }

        private void UpdateVisualization()
        {
            if (Root == null) return;

            // Clear existing visualizations
            NodesContainer.ItemsSource = null;
            ConnectionsContainer.ItemsSource = null;

            var nodesList = new System.Collections.Generic.List<TreeVisualization.TreeNodeVisual>();
            CollectNodes(Root, nodesList);

            var treeViz = new TreeVisualization(ActualWidth, ActualHeight);
            var connections = treeViz.GetConnections(Root);

            // Update visualizations
            NodesContainer.ItemsSource = nodesList;
            ConnectionsContainer.ItemsSource = connections;
        }

        private void CollectNodes(TreeVisualization.TreeNodeVisual node, System.Collections.Generic.List<TreeVisualization.TreeNodeVisual> nodes)
        {
            if (node == null) return;
            nodes.Add(node);
            CollectNodes(node.Left, nodes);
            CollectNodes(node.Right, nodes);
        }
    }
}