﻿using System;
using System.Windows.Controls;
using MunicipalServicesApp2.Services;
using MunicipalServicesApp2.ViewModels;
using MunicipalServicesApp2.Controls;
using MunicipalServicesApp2.Utilities;

namespace MunicipalServicesApp2.Views
{
    public partial class ServiceRequestStatusWindow : Page
    {
        private TreeVisualizer treeVisualizer;
        private GraphVisualizer graphVisualizer;

        public ServiceRequestStatusWindow(
            ServiceRequestManager serviceRequestManager,
            INavigationService navigationService,
            RequestTreeManager requestTreeManager,
            RequestGraphManager requestGraphManager)
        {
            InitializeComponent();

            // Initialize visualizers first
            InitializeVisualizers();

            // Set DataContext
            var viewModel = new ServiceRequestStatusViewModel(
                serviceRequestManager,
                navigationService,
                requestTreeManager,
                requestGraphManager);

            DataContext = viewModel;

            // Debug output
            System.Diagnostics.Debug.WriteLine($"Tree Visualizer: {treeVisualizer != null}");
            System.Diagnostics.Debug.WriteLine($"Graph Visualizer: {graphVisualizer != null}");

            // Set up event handlers
            this.Loaded += (s, e) =>
            {
                System.Diagnostics.Debug.WriteLine("Window Loaded");
                UpdateVisualizerSizes();
                UpdateVisualizations();
            };

            viewModel.PropertyChanged += (s, e) =>
            {
                if (e.PropertyName == nameof(ServiceRequestStatusViewModel.ServiceRequests) ||
                    e.PropertyName == nameof(ServiceRequestStatusViewModel.TreeRoot) ||
                    e.PropertyName == nameof(ServiceRequestStatusViewModel.GraphNodes) ||
                    e.PropertyName == nameof(ServiceRequestStatusViewModel.GraphEdges))
                {
                    System.Diagnostics.Debug.WriteLine($"Property Changed: {e.PropertyName}");
                    UpdateVisualizations();
                }
            };

            this.SizeChanged += (s, e) =>
            {
                UpdateVisualizerSizes();
            };
        }

        private void InitializeVisualizers()
        {
            treeVisualizer = this.FindName("TreeView") as TreeVisualizer;
            graphVisualizer = this.FindName("GraphView") as GraphVisualizer;

            System.Diagnostics.Debug.WriteLine($"Initializing - Tree Visualizer Found: {treeVisualizer != null}");
            System.Diagnostics.Debug.WriteLine($"Initializing - Graph Visualizer Found: {graphVisualizer != null}");

            if (treeVisualizer != null)
            {
                treeVisualizer.Width = 350;
                treeVisualizer.Height = 300;
            }

            if (graphVisualizer != null)
            {
                graphVisualizer.Width = 350;
                graphVisualizer.Height = 300;
            }
        }

        private void UpdateVisualizerSizes()
        {
            if (treeVisualizer != null)
            {
                treeVisualizer.Width = this.ActualWidth * 0.4;
                treeVisualizer.Height = Math.Min(this.ActualHeight * 0.4, 400);
                System.Diagnostics.Debug.WriteLine($"Tree Size Updated: {treeVisualizer.Width}x{treeVisualizer.Height}");
            }

            if (graphVisualizer != null)
            {
                graphVisualizer.Width = this.ActualWidth * 0.4;
                graphVisualizer.Height = Math.Min(this.ActualHeight * 0.4, 400);
                System.Diagnostics.Debug.WriteLine($"Graph Size Updated: {graphVisualizer.Width}x{graphVisualizer.Height}");
            }
        }

        private void UpdateVisualizations()
        {
            if (DataContext is ServiceRequestStatusViewModel viewModel)
            {
                if (viewModel.TreeRoot != null && treeVisualizer != null)
                {
                    System.Diagnostics.Debug.WriteLine("Updating Tree Visualization");
                    treeVisualizer.Root = viewModel.TreeRoot;
                    treeVisualizer.UpdateLayout();
                }

                if (graphVisualizer != null)
                {
                    System.Diagnostics.Debug.WriteLine($"Updating Graph Visualization - Nodes: {viewModel.GraphNodes?.Count}, Edges: {viewModel.GraphEdges?.Count}");
                    if (viewModel.GraphNodes != null)
                        graphVisualizer.Nodes = viewModel.GraphNodes;

                    if (viewModel.GraphEdges != null)
                        graphVisualizer.Edges = viewModel.GraphEdges;

                    graphVisualizer.UpdateLayout();
                }
            }
        }
    }
}