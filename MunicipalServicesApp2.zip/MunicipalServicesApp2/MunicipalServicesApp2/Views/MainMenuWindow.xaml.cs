﻿using System.Windows.Controls;
using MunicipalServicesApp2.Services;
using MunicipalServicesApp2.ViewModels;

namespace MunicipalServicesApp2.Views
{
    public partial class MainMenuWindow : Page
    {
        public MainMenuWindow(INavigationService navigationService, UserEngagementService userEngagementService)
        {
            InitializeComponent();
            DataContext = new MainMenuViewModel(navigationService, userEngagementService);
        }
    }
}