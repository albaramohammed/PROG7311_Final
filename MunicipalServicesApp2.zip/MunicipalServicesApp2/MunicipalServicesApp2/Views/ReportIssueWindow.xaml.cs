﻿using System.Windows.Controls;
using MunicipalServicesApp2.ViewModels;
using MunicipalServicesApp2.Services;

namespace MunicipalServicesApp2.Views
{
    public partial class ReportIssueWindow : Page
    {
        public ReportIssueWindow(INavigationService navigationService, IssueManager issueManager, UserEngagementService userEngagementService)
        {
            InitializeComponent();
            DataContext = new ReportIssueViewModel(navigationService, issueManager, userEngagementService);
        }
    }
}