﻿using System;
using System.Collections.Generic;
using System.Linq;
using MunicipalServicesApp2.Utilities;

namespace MunicipalServicesApp2.Services
{
    public class UserEngagementService
    {
        private CustomStack<string> recentActions;
        private CustomPriorityQueue<string> notifications;
        private int userPoints;
        private HashSet<string> achievements;

        public UserEngagementService()
        {
            recentActions = new CustomStack<string>();
            notifications = new CustomPriorityQueue<string>();
            userPoints = 0;
            achievements = new HashSet<string>();
        }

        public void LogUserAction(string action)
        {
            recentActions.Push(action);
            AddPoints(10);
            CheckAchievements();
        }

        public List<string> GetRecentActions(int count)
        {
            return recentActions.ToList().Take(count).ToList();
        }

        public void AddNotification(string message, int priority)
        {
            notifications.Enqueue(message, priority);
        }

        public string GetNextNotification()
        {
            return notifications.IsEmpty() ? null : notifications.Dequeue();
        }

        public void AddPoints(int points)
        {
            userPoints += points;
        }

        public int GetUserPoints()
        {
            return userPoints;
        }

        private void CheckAchievements()
        {
            if (userPoints >= 100 && !achievements.Contains("Active Citizen"))
            {
                achievements.Add("Active Citizen");
                AddNotification("Achievement Unlocked: Active Citizen!", 1);
            }

            if (recentActions.Count >= 10 && !achievements.Contains("Engaged Resident"))
            {
                achievements.Add("Engaged Resident");
                AddNotification("Achievement Unlocked: Engaged Resident!", 1);
            }
        }

        public List<string> GetAchievements()
        {
            return achievements.ToList();
        }
    }
}