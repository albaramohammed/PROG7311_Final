﻿using System;
using System.Windows.Controls;
using MunicipalServicesApp2.Views;

namespace MunicipalServicesApp2.Services
{
    public class NavigationService : INavigationService
    {
        private readonly Frame _frame;
        private readonly MunicipalServicesApp2.Services.EventManager _eventManager;
        private readonly AnnouncementManager _announcementManager;
        private readonly IssueManager _issueManager;
        private readonly UserEngagementService _userEngagementService;
        private readonly SearchEngine _searchEngine;
        private readonly ServiceRequestManager _serviceRequestManager;

        public NavigationService(Frame frame, MunicipalServicesApp2.Services.EventManager eventManager,
            AnnouncementManager announcementManager, IssueManager issueManager,
            UserEngagementService userEngagementService, SearchEngine searchEngine,
            ServiceRequestManager serviceRequestManager)
        {
            _frame = frame;
            _eventManager = eventManager;
            _announcementManager = announcementManager;
            _issueManager = issueManager;
            _userEngagementService = userEngagementService;
            _searchEngine = searchEngine;
            _serviceRequestManager = serviceRequestManager;
        }

        public void NavigateTo(string viewName)
        {
            switch (viewName)
            {
                case "ReportIssue":
                    _frame.Navigate(new ReportIssueWindow(this, _issueManager, _userEngagementService));
                    break;
                case "EventsAndAnnouncements":
                    _frame.Navigate(new LocalEventsAndAnnouncementsWindow(_eventManager, _announcementManager, _searchEngine, this));
                    break;
                case "MainMenu":
                    _frame.Navigate(new MainMenuWindow(this, _userEngagementService));
                    break;
                case "ServiceRequestStatus":
                    _frame.Navigate(new ServiceRequestStatusWindow(_serviceRequestManager, this));
                    break;
                default:
                    throw new ArgumentException($"View not found: {viewName}");
            }
        }
    }
}