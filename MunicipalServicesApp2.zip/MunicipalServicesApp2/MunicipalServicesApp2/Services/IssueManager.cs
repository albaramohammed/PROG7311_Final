﻿using MunicipalServicesApp2.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MunicipalServicesApp2.Services
{
    public class IssueManager
    {
        private List<Issue> reportedIssues;

        public IssueManager()
        {
            reportedIssues = new List<Issue>();
            InitializeIssues();
        }

        private void InitializeIssues()
        {
            AddIssue(new Issue(1, "Pothole on Main Street", "Main Street", "Road Maintenance", "Large pothole near the intersection of Main and Oak."));
            AddIssue(new Issue(2, "Broken Swing in City Park", "City Park", "Parks and Recreation", "Broken swing in the children's playground area."));
            AddIssue(new Issue(3, "Streetlight Out Downtown", "Downtown", "Street Lighting", "Streetlight out on corner of 1st and Pine."));
        }

        public void AddIssue(Issue issue)
        {
            reportedIssues.Add(issue);
        }

        public List<Issue> GetIssuesByCategory(string category)
        {
            return reportedIssues.Where(i => i.Category == category).ToList();
        }

        public List<Issue> GetAllIssues()
        {
            return reportedIssues;
        }

        public void UpdateIssueStatus(int issueId, string newStatus)
        {
            var issue = reportedIssues.FirstOrDefault(i => i.Id == issueId);
            if (issue != null)
            {
                issue.Status = newStatus;
            }
        }
    }
}