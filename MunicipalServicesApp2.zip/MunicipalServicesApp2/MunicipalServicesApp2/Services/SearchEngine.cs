﻿using System;
using System.Collections.Generic;
using System.Linq;
using MunicipalServicesApp2.Models;

namespace MunicipalServicesApp2.Services
{
    public class SearchEngine
    {
        private readonly EventManager _eventManager;
        private Dictionary<string, int> _searchHistory;

        public SearchEngine(EventManager eventManager)
        {
            _eventManager = eventManager;
            _searchHistory = new Dictionary<string, int>();
        }

        public List<Event> SearchEvents(string query, DateTime? date = null, string category = null)
        {
            UpdateSearchHistory(query);
            var allEvents = _eventManager.GetAllEvents();

            return allEvents.Where(e =>
                (string.IsNullOrEmpty(query) ||
                 e.Title.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0 ||
                 e.Description.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0) &&
                (!date.HasValue || e.Date.Date == date.Value.Date) &&
                (string.IsNullOrEmpty(category) || category == "All" || e.Category == category)
            ).ToList();
        }

        public List<Event> GetRecommendedEvents(int count = 5)
        {
            var topSearches = _searchHistory.OrderByDescending(x => x.Value).Take(3).Select(x => x.Key).ToList();
            var allEvents = _eventManager.GetAllEvents();

            return allEvents.Where(e =>
                topSearches.Any(s => e.Title.IndexOf(s, StringComparison.OrdinalIgnoreCase) >= 0 ||
                                     e.Description.IndexOf(s, StringComparison.OrdinalIgnoreCase) >= 0 ||
                                     e.Category.IndexOf(s, StringComparison.OrdinalIgnoreCase) >= 0)
            ).Take(count).ToList();
        }

        private void UpdateSearchHistory(string query)
        {
            if (!string.IsNullOrEmpty(query))
            {
                if (_searchHistory.ContainsKey(query))
                {
                    _searchHistory[query]++;
                }
                else
                {
                    _searchHistory[query] = 1;
                }
            }
        }
    }
}