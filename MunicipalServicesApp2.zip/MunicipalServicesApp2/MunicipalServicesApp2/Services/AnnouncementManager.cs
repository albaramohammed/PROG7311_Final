﻿using System;
using System.Collections.Generic;
using System.Linq;
using MunicipalServicesApp2.Models;
using MunicipalServicesApp2.Utilities;

namespace MunicipalServicesApp2.Services
{
    public class AnnouncementManager
    {
        private CustomQueue<Announcement> announcements;

        public AnnouncementManager()
        {
            announcements = new CustomQueue<Announcement>();
            InitializeAnnouncements();
        }

        private void InitializeAnnouncements()
        {
            announcements.Enqueue(new Announcement(1, "City Hall Renovation", DateTime.Now.AddDays(-5), "City Hall will be closed for renovations next month."));
            announcements.Enqueue(new Announcement(2, "New Recycling Program", DateTime.Now.AddDays(-2), "A new recycling program will be launched next week."));
            announcements.Enqueue(new Announcement(3, "Water Conservation Notice", DateTime.Now, "Please conserve water due to the ongoing drought."));
        }

        public void AddAnnouncement(Announcement announcement)
        {
            announcements.Enqueue(announcement);
        }

        public List<Announcement> GetRecentAnnouncements(int count)
        {
            return announcements.ToList().Take(count).ToList();
        }
    }
}