﻿using MunicipalServicesApp2.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MunicipalServicesApp2.Services
{
    public class ServiceRequestManager
    {
        private CustomPriorityQueue<ServiceRequest> serviceRequests;

        public ServiceRequestManager()
        {
            serviceRequests = new CustomPriorityQueue<ServiceRequest>();
            InitializeServiceRequests();
        }

        private void InitializeServiceRequests()
        {
            AddServiceRequest(new ServiceRequest(1, "Fix Pothole", "In Progress", DateTime.Now.AddDays(-5), "Repairing pothole on Main Street"));
            AddServiceRequest(new ServiceRequest(2, "Street Light Repair", "Pending", DateTime.Now.AddDays(-2), "Replace broken street light on Oak Avenue"));
            AddServiceRequest(new ServiceRequest(3, "Park Cleanup", "Completed", DateTime.Now.AddDays(-7), "General cleanup of City Park"));
        }

        public void AddServiceRequest(ServiceRequest request)
        {
            int priority = GetPriority(request.Status);
            serviceRequests.Enqueue(request, priority);
        }

        public List<ServiceRequest> GetAllServiceRequests()
        {
            return serviceRequests.ToList();
        }

        private int GetPriority(string status)
        {
            switch (status.ToLower())
            {
                case "in progress":
                    return 3;
                case "pending":
                    return 2;
                case "completed":
                    return 1;
                default:
                    return 0;
            }
        }
    }
}
