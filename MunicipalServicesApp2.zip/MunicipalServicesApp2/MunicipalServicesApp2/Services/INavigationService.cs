﻿using System;
using System.Windows.Controls;
using MunicipalServicesApp2.Views;

namespace MunicipalServicesApp2.Services
{
    public interface INavigationService
    {
        void NavigateTo(string viewName);
    }
}