﻿using MunicipalServicesApp2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MunicipalServicesApp2.Services
{
    public class EventManager
    {
        private SortedDictionary<DateTime, List<Event>> eventsByDate;
        private Dictionary<string, HashSet<Event>> eventsByCategory;

        public EventManager()
        {
            eventsByDate = new SortedDictionary<DateTime, List<Event>>();
            eventsByCategory = new Dictionary<string, HashSet<Event>>();
            InitializeEvents();
        }

        private void InitializeEvents()
        {
            AddEvent(new Event(1, "Community Cleanup", DateTime.Now.AddDays(7), "Environment", "Join us for a community-wide cleanup event."));
            AddEvent(new Event(2, "Town Hall Meeting", DateTime.Now.AddDays(14), "Civic", "Discuss upcoming city projects at the town hall meeting."));
            AddEvent(new Event(3, "Summer Festival", DateTime.Now.AddDays(30), "Culture", "Annual summer festival with food, music, and activities."));
        }

        public void AddEvent(Event newEvent)
        {
            if (!eventsByDate.ContainsKey(newEvent.Date))
            {
                eventsByDate[newEvent.Date] = new List<Event>();
            }
            eventsByDate[newEvent.Date].Add(newEvent);

            if (!eventsByCategory.ContainsKey(newEvent.Category))
            {
                eventsByCategory[newEvent.Category] = new HashSet<Event>();
            }
            eventsByCategory[newEvent.Category].Add(newEvent);
        }

        public List<Event> GetEventsByDate(DateTime date)
        {
            return eventsByDate.ContainsKey(date) ? eventsByDate[date] : new List<Event>();
        }

        public HashSet<Event> GetEventsByCategory(string category)
        {
            return eventsByCategory.ContainsKey(category) ? eventsByCategory[category] : new HashSet<Event>();
        }

        public List<Event> GetAllEvents()
        {
            return eventsByDate.Values.SelectMany(e => e).ToList();
        }
    }
}
