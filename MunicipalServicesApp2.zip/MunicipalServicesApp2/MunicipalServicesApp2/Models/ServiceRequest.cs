﻿using System;

public class ServiceRequest
{
    public int Id { get; set; }
    public string Title { get; set; }
    public string Status { get; set; }
    public DateTime RequestDate { get; set; }
    public string Description { get; set; }

    public ServiceRequest(int id, string title, string status, DateTime requestDate, string description)
    {
        Id = id;
        Title = title;
        Status = status;
        RequestDate = requestDate;
        Description = description;
    }
}