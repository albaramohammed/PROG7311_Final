﻿using System.Collections.ObjectModel;
using System.Windows.Input;
using MunicipalServicesApp2.Models;
using MunicipalServicesApp2.Services;
using MunicipalServicesApp2.Commands;

namespace MunicipalServicesApp2.ViewModels
{
    public class ServiceRequestStatusViewModel : ViewModelBase
    {
        private readonly ServiceRequestManager _serviceRequestManager;
        private readonly INavigationService _navigationService;
        private ObservableCollection<ServiceRequest> _serviceRequests;

        public ServiceRequestStatusViewModel(ServiceRequestManager serviceRequestManager, INavigationService navigationService)
        {
            _serviceRequestManager = serviceRequestManager;
            _navigationService = navigationService;
            LoadServiceRequests();
        }

        public ObservableCollection<ServiceRequest> ServiceRequests
        {
            get => _serviceRequests;
            set
            {
                _serviceRequests = value;
                OnPropertyChanged(nameof(ServiceRequests));
            }
        }

        private ICommand _backCommand;
        public ICommand BackCommand
        {
            get
            {
                return _backCommand ?? (_backCommand = new RelayCommand(
                    param => NavigateBack()
                ));
            }
        }

        private void LoadServiceRequests()
        {
            ServiceRequests = new ObservableCollection<ServiceRequest>(_serviceRequestManager.GetAllServiceRequests());
        }

        private void NavigateBack()
        {
            _navigationService.NavigateTo("MainMenu");
        }
    }
}