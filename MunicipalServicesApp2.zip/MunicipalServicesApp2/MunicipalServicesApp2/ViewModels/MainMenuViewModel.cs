﻿using System.Windows.Input;
using MunicipalServicesApp2.Services;
using MunicipalServicesApp2.Commands;
using System.Linq;

namespace MunicipalServicesApp2.ViewModels
{
    public class MainMenuViewModel : ViewModelBase
    {
        private readonly INavigationService _navigationService;
        private readonly UserEngagementService _userEngagementService;

        public MainMenuViewModel(INavigationService navigationService, UserEngagementService userEngagementService)
        {
            _navigationService = navigationService;
            _userEngagementService = userEngagementService;
        }

        public int UserPoints => _userEngagementService.GetUserPoints();

        public string LatestAchievement => _userEngagementService.GetAchievements().LastOrDefault() ?? "No achievements yet";

        private ICommand _navigateToReportIssueCommand;
        public ICommand NavigateToReportIssueCommand
        {
            get
            {
                return _navigateToReportIssueCommand ?? (_navigateToReportIssueCommand = new RelayCommand(
                    param => NavigateToReportIssue()
                ));
            }
        }

        private ICommand _navigateToEventsAndAnnouncementsCommand;
        public ICommand NavigateToEventsAndAnnouncementsCommand
        {
            get
            {
                return _navigateToEventsAndAnnouncementsCommand ?? (_navigateToEventsAndAnnouncementsCommand = new RelayCommand(
                    param => NavigateToEventsAndAnnouncements()
                ));
            }
        }

        private ICommand _navigateToServiceRequestStatusCommand;
        public ICommand NavigateToServiceRequestStatusCommand
        {
            get
            {
                return _navigateToServiceRequestStatusCommand ?? (_navigateToServiceRequestStatusCommand = new RelayCommand(
                    param => NavigateToServiceRequestStatus()
                ));
            }
        }

        private void NavigateToReportIssue()
        {
            _navigationService.NavigateTo("ReportIssue");
        }

        private void NavigateToEventsAndAnnouncements()
        {
            _navigationService.NavigateTo("EventsAndAnnouncements");
        }

        private void NavigateToServiceRequestStatus()
        {
            _navigationService.NavigateTo("ServiceRequestStatus");
        }
    }
}