﻿using System.Collections.Generic;
using System.Windows.Input;
using MunicipalServicesApp2.Models;
using MunicipalServicesApp2.Services;
using MunicipalServicesApp2.Commands;

namespace MunicipalServicesApp2.ViewModels
{
    public class ReportIssueViewModel : ViewModelBase
    {
        private readonly INavigationService _navigationService;
        private readonly IssueManager _issueManager;
        private readonly UserEngagementService _userEngagementService;

        private string _title;
        private string _location;
        private string _category;
        private string _description;

        public ReportIssueViewModel(INavigationService navigationService, IssueManager issueManager, UserEngagementService userEngagementService)
        {
            _navigationService = navigationService;
            _issueManager = issueManager;
            _userEngagementService = userEngagementService;
            InitializeCategories();
        }

        public string Title
        {
            get => _title;
            set
            {
                _title = value;
                OnPropertyChanged(nameof(Title));
            }
        }

        public string Location
        {
            get => _location;
            set
            {
                _location = value;
                OnPropertyChanged(nameof(Location));
            }
        }

        public string Category
        {
            get => _category;
            set
            {
                _category = value;
                OnPropertyChanged(nameof(Category));
            }
        }

        public string Description
        {
            get => _description;
            set
            {
                _description = value;
                OnPropertyChanged(nameof(Description));
            }
        }

        public List<string> Categories { get; private set; }

        private ICommand _submitIssueCommand;
        public ICommand SubmitIssueCommand
        {
            get
            {
                return _submitIssueCommand ?? (_submitIssueCommand = new RelayCommand(
                    param => SubmitIssue(),
                    param => CanSubmitIssue()
                ));
            }
        }

        private ICommand _backCommand;
        public ICommand BackCommand
        {
            get
            {
                return _backCommand ?? (_backCommand = new RelayCommand(
                    param => NavigateBack()
                ));
            }
        }

        private bool CanSubmitIssue()
        {
            return !string.IsNullOrWhiteSpace(Title) &&
                   !string.IsNullOrWhiteSpace(Location) &&
                   !string.IsNullOrWhiteSpace(Category) &&
                   !string.IsNullOrWhiteSpace(Description);
        }

        private void SubmitIssue()
        {
            var newIssue = new Issue(_issueManager.GetAllIssues().Count + 1, Title, Location, Category, Description);
            _issueManager.AddIssue(newIssue);
            _userEngagementService.LogUserAction($"Reported issue: {newIssue.Title} at {newIssue.Location}");

            // Reset fields after submission
            Title = "";
            Location = "";
            Category = "";
            Description = "";

            // Navigate back to main menu
            NavigateBack();
        }

        private void NavigateBack()
        {
            _navigationService.NavigateTo("MainMenu");
        }

        private void InitializeCategories()
        {
            Categories = new List<string>
            {
                "Road Maintenance",
                "Waste Management",
                "Public Safety",
                "Parks and Recreation",
                "Water Supply",
                "Street Lighting",
                "Other"
            };
        }
    }
}