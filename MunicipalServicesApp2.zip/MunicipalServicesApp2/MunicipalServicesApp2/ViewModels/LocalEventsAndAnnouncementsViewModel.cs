﻿using System;
using System.Collections.ObjectModel;
using System.Windows.Input;
using MunicipalServicesApp2.Models;
using MunicipalServicesApp2.Services;
using MunicipalServicesApp2.Commands;

namespace MunicipalServicesApp2.ViewModels
{
    public class LocalEventsAndAnnouncementsViewModel : ViewModelBase
    {
        private readonly EventManager _eventManager;
        private readonly AnnouncementManager _announcementManager;
        private readonly SearchEngine _searchEngine;
        private readonly INavigationService _navigationService;
        private ObservableCollection<Event> _events;
        private ObservableCollection<Announcement> _announcements;
        private ObservableCollection<Event> _recommendedEvents;
        private string _searchQuery;
        private DateTime? _searchDate;
        private string _selectedCategory;
        private ICommand _searchCommand;
        private ICommand _backCommand;

        public LocalEventsAndAnnouncementsViewModel(EventManager eventManager, AnnouncementManager announcementManager, SearchEngine searchEngine, INavigationService navigationService)
        {
            _eventManager = eventManager;
            _announcementManager = announcementManager;
            _searchEngine = searchEngine;
            _navigationService = navigationService;
            LoadEventsAndAnnouncements();
            LoadRecommendedEvents();
        }

        public ObservableCollection<Event> Events
        {
            get => _events;
            set
            {
                _events = value;
                OnPropertyChanged(nameof(Events));
            }
        }

        public ObservableCollection<Announcement> Announcements
        {
            get => _announcements;
            set
            {
                _announcements = value;
                OnPropertyChanged(nameof(Announcements));
            }
        }

        public ObservableCollection<Event> RecommendedEvents
        {
            get => _recommendedEvents;
            set
            {
                _recommendedEvents = value;
                OnPropertyChanged(nameof(RecommendedEvents));
            }
        }

        public string SearchQuery
        {
            get => _searchQuery;
            set
            {
                _searchQuery = value;
                OnPropertyChanged(nameof(SearchQuery));
            }
        }

        public DateTime? SearchDate
        {
            get => _searchDate;
            set
            {
                _searchDate = value;
                OnPropertyChanged(nameof(SearchDate));
            }
        }

        public string SelectedCategory
        {
            get => _selectedCategory;
            set
            {
                _selectedCategory = value;
                OnPropertyChanged(nameof(SelectedCategory));
            }
        }

        public ObservableCollection<string> Categories { get; } = new ObservableCollection<string>
        {
            "All",
            "Community",
            "Sports",
            "Culture",
            "Education",
            "Other"
        };

        public ICommand SearchCommand
        {
            get
            {
                return _searchCommand ?? (_searchCommand = new RelayCommand(
                    param => SearchEvents(),
                    param => CanSearch()
                ));
            }
        }

        public ICommand BackCommand
        {
            get
            {
                return _backCommand ?? (_backCommand = new RelayCommand(
                    param => NavigateBack()
                ));
            }
        }

        private bool CanSearch()
        {
            return !string.IsNullOrWhiteSpace(SearchQuery) || SearchDate.HasValue || !string.IsNullOrWhiteSpace(SelectedCategory);
        }

        private void SearchEvents()
        {
            var searchResults = _searchEngine.SearchEvents(SearchQuery, SearchDate, SelectedCategory);
            Events = new ObservableCollection<Event>(searchResults);
            LoadRecommendedEvents();
        }

        private void LoadEventsAndAnnouncements()
        {
            Events = new ObservableCollection<Event>(_eventManager.GetAllEvents());
            Announcements = new ObservableCollection<Announcement>(_announcementManager.GetRecentAnnouncements(5));
        }

        private void LoadRecommendedEvents()
        {
            RecommendedEvents = new ObservableCollection<Event>(_searchEngine.GetRecommendedEvents());
        }

        private void NavigateBack()
        {
            _navigationService.NavigateTo("MainMenu");
        }
    }
}