﻿using System.Windows;
using System.Windows.Controls;
using MunicipalServicesApp2.Services;

namespace MunicipalServicesApp2
{
    public partial class MainWindow : Window
    {
        private INavigationService _navigationService;

        public MainWindow()
        {
            InitializeComponent();
        }

        public void InitializeServices(
            MunicipalServicesApp2.Services.EventManager eventManager,
            AnnouncementManager announcementManager,
            IssueManager issueManager,
            UserEngagementService userEngagementService,
            SearchEngine searchEngine,
            ServiceRequestManager serviceRequestManager)
        {
            _navigationService = new NavigationService(
                MainFrame,
                eventManager,
                announcementManager,
                issueManager,
                userEngagementService,
                searchEngine,
                serviceRequestManager
            );
        }

        public void NavigateToMainMenu()
        {
            _navigationService.NavigateTo("MainMenu");
        }
    }
}