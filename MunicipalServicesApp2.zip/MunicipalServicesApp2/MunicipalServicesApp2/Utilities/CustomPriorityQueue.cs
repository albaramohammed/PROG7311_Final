﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MunicipalServicesApp2.Utilities
{
    public class CustomPriorityQueue<T>
    {
        private List<Tuple<T, int>> items = new List<Tuple<T, int>>();

        public void Enqueue(T item, int priority)
        {
            items.Add(new Tuple<T, int>(item, priority));
            items.Sort((a, b) => b.Item2.CompareTo(a.Item2)); // Sort in descending order of priority
        }

        public T Dequeue()
        {
            if (IsEmpty())
                throw new InvalidOperationException("The priority queue is empty");
            T item = items[0].Item1;
            items.RemoveAt(0);
            return item;
        }

        public T Peek()
        {
            if (IsEmpty())
                throw new InvalidOperationException("The priority queue is empty");
            return items[0].Item1;
        }

        public bool IsEmpty() => items.Count == 0;

        public int Count => items.Count;

        public List<T> ToList() => items.Select(i => i.Item1).ToList();
    }
}
