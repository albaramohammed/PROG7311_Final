﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MunicipalServicesApp2.Utilities
{
    public class CustomQueue<T> : IDataStructure<T>
    {
        private List<T> items = new List<T>();

        public void Add(T item)
        {
            items.Add(item);
        }

        public T Remove()
        {
            if (IsEmpty())
                throw new InvalidOperationException("The queue is empty");
            T item = items[0];
            items.RemoveAt(0);
            return item;
        }

        public T Peek()
        {
            if (IsEmpty())
                throw new InvalidOperationException("The queue is empty");
            return items[0];
        }

        public bool IsEmpty() => items.Count == 0;

        public int Count => items.Count;

        public void Enqueue(T item) => Add(item);

        public T Dequeue() => Remove();

        public List<T> ToList() => new List<T>(items);
    }
}
