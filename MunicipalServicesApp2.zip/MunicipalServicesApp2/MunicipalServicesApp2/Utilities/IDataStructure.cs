﻿using System;
using System.Collections.Generic;

namespace MunicipalServicesApp2.Utilities
{
    public interface IDataStructure<T>
    {
        void Add(T item);
        T Remove();
        T Peek();
        bool IsEmpty();
        int Count { get; }
    }
}