﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MunicipalServicesApp2.Utilities
{
    public class CustomStack<T> : IDataStructure<T>
    {
        private List<T> items = new List<T>();

        public void Add(T item)
        {
            items.Add(item);
        }

        public T Remove()
        {
            if (IsEmpty())
                throw new InvalidOperationException("The stack is empty");
            T item = items[items.Count - 1];
            items.RemoveAt(items.Count - 1);
            return item;
        }

        public T Peek()
        {
            if (IsEmpty())
                throw new InvalidOperationException("The stack is empty");
            return items[items.Count - 1];
        }

        public bool IsEmpty() => items.Count == 0;

        public int Count => items.Count;

        public void Push(T item) => Add(item);

        public T Pop() => Remove();

        public List<T> ToList() => new List<T>(items);
    }

}
