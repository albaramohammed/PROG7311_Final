﻿    using System;
using System.Windows.Controls;
using MunicipalServicesApp2.Views;
using MunicipalServicesApp2.Services;

namespace MunicipalServicesApp2.Services
{
    /// <summary>
    /// Handles navigation between different views in the application
    /// </summary>
    public class NavigationService : INavigationService
    {
        #region Private Fields

        private readonly Frame _frame;
        private readonly EventManager _eventManager;
        private readonly AnnouncementManager _announcementManager;
        private readonly IssueManager _issueManager;
        private readonly UserEngagementService _userEngagementService;
        private readonly SearchEngine _searchEngine;
        private readonly ServiceRequestManager _serviceRequestManager;
        private readonly RequestTreeManager _requestTreeManager;
        private readonly RequestGraphManager _requestGraphManager;

        #endregion

        /// <summary>
        /// Initializes a new instance of the NavigationService with required dependencies
        /// </summary>
        public NavigationService(
            Frame frame,
            EventManager eventManager,
            AnnouncementManager announcementManager,
            IssueManager issueManager,
            UserEngagementService userEngagementService,
            SearchEngine searchEngine,
            ServiceRequestManager serviceRequestManager,
            RequestTreeManager requestTreeManager,
            RequestGraphManager requestGraphManager)
        {
            _frame = frame ?? throw new ArgumentNullException(nameof(frame));
            _eventManager = eventManager ?? throw new ArgumentNullException(nameof(eventManager));
            _announcementManager = announcementManager ?? throw new ArgumentNullException(nameof(announcementManager));
            _issueManager = issueManager ?? throw new ArgumentNullException(nameof(issueManager));
            _userEngagementService = userEngagementService ?? throw new ArgumentNullException(nameof(userEngagementService));
            _searchEngine = searchEngine ?? throw new ArgumentNullException(nameof(searchEngine));
            _serviceRequestManager = serviceRequestManager ?? throw new ArgumentNullException(nameof(serviceRequestManager));
            _requestTreeManager = requestTreeManager ?? throw new ArgumentNullException(nameof(requestTreeManager));
            _requestGraphManager = requestGraphManager ?? throw new ArgumentNullException(nameof(requestGraphManager));
        }

        /// <summary>
        /// Navigates to the specified view
        /// </summary>
        /// <param name="viewName">Name of the view to navigate to</param>
        /// <exception cref="ArgumentException">Thrown when view name is not recognized</exception>
        public void NavigateTo(string viewName)
        {
            try
            {
                switch (viewName)
                {
                    case "ReportIssue":
                        _frame.Navigate(new ReportIssueWindow(
                            this,
                            _issueManager,
                            _userEngagementService));
                        break;

                    case "EventsAndAnnouncements":
                        _frame.Navigate(new LocalEventsAndAnnouncementsWindow(
                            _eventManager,
                            _announcementManager,
                            _searchEngine,
                            this));
                        break;

                    case "MainMenu":
                        _frame.Navigate(new MainMenuWindow(
                            this,
                            _userEngagementService));
                        break;

                    case "ServiceRequestStatus":
                        _frame.Navigate(new ServiceRequestStatusWindow(
                            _serviceRequestManager,
                            this,
                            _requestTreeManager,  // Make sure this is not null
                            _requestGraphManager  // Make sure this is not null
                        ));
                        break;

                    default:
                        throw new ArgumentException($"View not found: {viewName}");
                }

                // Log navigation for user engagement
                _userEngagementService.LogUserAction($"Navigated to {viewName}");
            }
            catch (Exception ex)
            {
                // In a production environment, you might want to log this error
                throw new NavigationException($"Error navigating to {viewName}", ex);
            }
        }

        /// <summary>
        /// Checks if navigation to a specific view is possible
        /// </summary>
        /// <param name="viewName">Name of the view to check</param>
        /// <returns>True if navigation is possible, false otherwise</returns>
        public bool CanNavigateTo(string viewName)
        {
            if (viewName == "ReportIssue")
                return _issueManager != null;
            else if (viewName == "EventsAndAnnouncements")
                return _eventManager != null && _announcementManager != null;
            else if (viewName == "MainMenu")
                return true;
            else if (viewName == "ServiceRequestStatus")
                return _serviceRequestManager != null;
            else
                return false;
        }

        /// <summary>
        /// Navigates back to the previous view if possible
        /// </summary>
        /// <returns>True if navigation was successful, false otherwise</returns>
        public bool NavigateBack()
        {
            if (_frame.CanGoBack)
            {
                _frame.GoBack();
                return true;
            }
            return false;
        }
    }

    /// <summary>
    /// Custom exception for navigation-related errors
    /// </summary>
    public class NavigationException : Exception
    {
        public NavigationException(string message) : base(message) { }
        public NavigationException(string message, Exception innerException) : base(message, innerException) { }
    }
}