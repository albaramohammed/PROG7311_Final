﻿using System;
using System.Collections.Generic;
using System.Linq;
using MunicipalServicesApp2.Models;
using MunicipalServicesApp2.Utilities;

namespace MunicipalServicesApp2.Services
{
    /// <summary>
    /// Manages service requests using various data structures for efficient handling and organization
    /// </summary>
    public class ServiceRequestManager
    {
        private readonly CustomPriorityQueue<ServiceRequest> serviceRequests;
        private readonly RequestTreeManager treeManager;
        private readonly RequestGraphManager graphManager;
        private readonly Dictionary<string, HashSet<ServiceRequest>> categoryRequests;
        private readonly Dictionary<string, HashSet<ServiceRequest>> locationRequests;

        /// <summary>
        /// Initializes the ServiceRequestManager with necessary data structures
        /// </summary>
        public ServiceRequestManager()
        {
            serviceRequests = new CustomPriorityQueue<ServiceRequest>();
            treeManager = new RequestTreeManager();
            graphManager = new RequestGraphManager();
            categoryRequests = new Dictionary<string, HashSet<ServiceRequest>>();
            locationRequests = new Dictionary<string, HashSet<ServiceRequest>>();
            InitializeServiceRequests();
        }

        /// <summary>
        /// Initializes the system with sample service requests
        /// </summary>
        private void InitializeServiceRequests()
        {
            AddServiceRequest(new ServiceRequest(
                1,
                "Fix Pothole",
                "In Progress",
                DateTime.Now.AddDays(-5),
                "Repairing pothole on Main Street",
                "Road Maintenance",
                "Main Street",
                "High"));

            AddServiceRequest(new ServiceRequest(
                2,
                "Street Light Repair",
                "Pending",
                DateTime.Now.AddDays(-2),
                "Replace broken street light on Oak Avenue",
                "Infrastructure",
                "Oak Avenue",
                "Medium"));

            AddServiceRequest(new ServiceRequest(
                3,
                "Park Cleanup",
                "Completed",
                DateTime.Now.AddDays(-7),
                "General cleanup of City Park",
                "Parks",
                "City Park",
                "Low"));
        }

        /// <summary>
        /// Adds a new service request to all data structures
        /// </summary>
        public void AddServiceRequest(ServiceRequest request)
        {
            // Add to priority queue
            int priority = GetPriority(request.Status, request.Priority);
            serviceRequests.Enqueue(request, priority);

            // Add to tree manager
            treeManager.AddRequest(request);

            // Add to graph manager
            graphManager.AddRequest(request);

            // Update category index
            if (!categoryRequests.ContainsKey(request.Category))
            {
                categoryRequests[request.Category] = new HashSet<ServiceRequest>();
            }
            categoryRequests[request.Category].Add(request);

            // Update location index
            if (!locationRequests.ContainsKey(request.Location))
            {
                locationRequests[request.Location] = new HashSet<ServiceRequest>();
            }
            locationRequests[request.Location].Add(request);
        }

        /// <summary>
        /// Gets priority value based on status
        /// </summary>
        private int GetStatusPriority(string status)
        {
            switch (status.ToLower())
            {
                case "in progress":
                    return 3;
                case "pending":
                    return 2;
                case "completed":
                    return 1;
                default:
                    return 0;
            }
        }

        /// <summary>
        /// Gets priority value based on priority level
        /// </summary>
        private int GetPriorityLevelValue(string priority)
        {
            switch (priority.ToLower())
            {
                case "urgent":
                    return 4;
                case "high":
                    return 3;
                case "medium":
                    return 2;
                case "low":
                    return 1;
                default:
                    return 0;
            }
        }

        /// <summary>
        /// Calculates combined priority based on status and priority level
        /// </summary>
        private int GetPriority(string status, string priority)
        {
            int statusPriority = GetStatusPriority(status);
            int levelPriority = GetPriorityLevelValue(priority);
            return statusPriority + levelPriority;
        }

        /// <summary>
        /// Retrieves all service requests
        /// </summary>
        public List<ServiceRequest> GetAllServiceRequests()
        {
            return serviceRequests.ToList();
        }

        /// <summary>
        /// Gets service requests filtered by specific criteria
        /// </summary>
        public List<ServiceRequest> GetFilteredRequests(string status = null, string category = null, string location = null)
        {
            var requests = GetAllServiceRequests();

            return requests.Where(r =>
                (string.IsNullOrEmpty(status) || r.Status.Equals(status, StringComparison.OrdinalIgnoreCase)) &&
                (string.IsNullOrEmpty(category) || r.Category.Equals(category, StringComparison.OrdinalIgnoreCase)) &&
                (string.IsNullOrEmpty(location) || r.Location.Equals(location, StringComparison.OrdinalIgnoreCase)))
                .ToList();
        }

        /// <summary>
        /// Gets related service requests based on location and category
        /// </summary>
        public List<ServiceRequest> GetRelatedRequests(int requestId)
        {
            return graphManager.GetRelatedRequests(requestId);
        }

        /// <summary>
        /// Updates the status of a service request
        /// </summary>
        public void UpdateRequestStatus(int requestId, string newStatus)
        {
            var request = GetAllServiceRequests().FirstOrDefault(r => r.Id == requestId);
            if (request != null)
            {
                request.UpdateStatus(newStatus);

                if (graphManager != null)
                    graphManager.UpdateRequestStatus(request, newStatus);

                if (treeManager != null)
                    treeManager.UpdateRequestStatus(request, newStatus);

                serviceRequests.Enqueue(request, GetPriority(newStatus, request.Priority));
            }
        }

        /// <summary>
        /// Gets requests sorted by priority
        /// </summary>
        public List<ServiceRequest> GetRequestsByPriority()
        {
            return graphManager.GetRequestsByPriority();
        }

        /// <summary>
        /// Gets requests grouped by category
        /// </summary>
        public Dictionary<string, List<ServiceRequest>> GetRequestsByCategory()
        {
            return categoryRequests.ToDictionary(
                kvp => kvp.Key,
                kvp => kvp.Value.ToList());
        }

        /// <summary>
        /// Gets requests grouped by location
        /// </summary>
        public Dictionary<string, List<ServiceRequest>> GetRequestsByLocation()
        {
            return locationRequests.ToDictionary(
                kvp => kvp.Key,
                kvp => kvp.Value.ToList());
        }

        /// <summary>
        /// Gets statistics about service requests
        /// </summary>
        public Dictionary<string, int> GetRequestStatistics()
        {
            var stats = new Dictionary<string, int>
            {
                {"Total Requests", GetAllServiceRequests().Count},
                {"Pending Requests", GetFilteredRequests(status: "Pending").Count},
                {"In Progress Requests", GetFilteredRequests(status: "In Progress").Count},
                {"Completed Requests", GetFilteredRequests(status: "Completed").Count}
            };

            foreach (var category in categoryRequests.Keys)
            {
                stats[$"Category: {category}"] = categoryRequests[category].Count;
            }

            return stats;
        }
    }
}