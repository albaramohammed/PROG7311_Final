﻿
using System;
using System.Collections.Generic;
using System.Linq;
using MunicipalServicesApp2.Models;
using MunicipalServicesApp2.Utilities;

namespace MunicipalServicesApp2.Services
{
    public class RequestTreeManager
    {
        #region Private Fields
        private readonly BinarySearchTree<ServiceRequest> binarySearchTree;
        private readonly AVLTree<ServiceRequest> avlTree;
        private readonly RedBlackTree<ServiceRequest> redBlackTree;
        private readonly Dictionary<string, List<ServiceRequest>> categoryIndex;
        private readonly Dictionary<string, List<ServiceRequest>> locationIndex;
        #endregion

        #region Constructor
        public RequestTreeManager()
        {
            binarySearchTree = new BinarySearchTree<ServiceRequest>();
            avlTree = new AVLTree<ServiceRequest>();
            redBlackTree = new RedBlackTree<ServiceRequest>();
            categoryIndex = new Dictionary<string, List<ServiceRequest>>();
            locationIndex = new Dictionary<string, List<ServiceRequest>>();
        }
        #endregion

        #region Public Methods

        /// <summary>
        /// Adds a new service request to all tree structures
        /// </summary>
        public void AddRequest(ServiceRequest request)
        {
            try
            {
                // Add to each tree structure
                binarySearchTree.Insert(request);
                avlTree.Insert(request);
                redBlackTree.Insert(request);

                // Update category index
                UpdateCategoryIndex(request);

                // Update location index
                UpdateLocationIndex(request);

                // Update visual properties
                UpdateRequestVisualProperties(request);
            }
            catch (Exception ex)
            {
                // Log the error in a production environment
                throw new InvalidOperationException($"Error adding request: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Gets the visualization tree for display
        /// </summary>
        public TreeVisualization.TreeNodeVisual GetVisualizationTree()
        {
            try
            {
                var root = avlTree.GetRoot();
                if (root == null) return null;
                return ConvertToVisual(root, 0, 0);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Error creating visualization tree", ex);
            }
        }
        /// <summary>
        /// Updates the status of a request
        /// </summary>
        public void UpdateRequestStatus(ServiceRequest request, string newStatus)
        {
            try
            {
                request.UpdateStatus(newStatus);

                // Remove and reinsert in all trees with new status
                binarySearchTree.Insert(request);
                avlTree.Insert(request);
                redBlackTree.Insert(request);

                // Update indexes
                UpdateCategoryIndex(request);
                UpdateRequestVisualProperties(request);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Error updating request status: {ex.Message}", ex);
            }
        }
        /// <summary>
        /// Gets the height of the tree
        /// </summary>
        public int GetTreeHeight()
        {
            return avlTree.GetHeight();
        }

        /// <summary>
        /// Gets requests by category
        /// </summary>
        public List<ServiceRequest> GetRequestsByCategory(string category)
        {
            if (string.IsNullOrEmpty(category)) return new List<ServiceRequest>();

            return categoryIndex.ContainsKey(category)
                ? new List<ServiceRequest>(categoryIndex[category])
                : new List<ServiceRequest>();
        }

        /// <summary>
        /// Gets requests sorted by date
        /// </summary>
        public List<ServiceRequest> GetRequestsSortedByDate()
        {
            return binarySearchTree.InOrderTraversal();
        }

        /// <summary>
        /// Gets requests sorted by priority
        /// </summary>
        public List<ServiceRequest> GetRequestsSortedByPriority()
        {
            return avlTree.InOrderTraversal();
        }

        /// <summary>
        /// Searches for a specific request
        /// </summary>
        public bool SearchRequest(ServiceRequest request)
        {
            if (request == null) return false;

            var bstResult = binarySearchTree.Search(request);
            var avlResult = avlTree.Search(request);
            var rbResult = redBlackTree.Search(request);

            return bstResult != null || avlResult != null || rbResult != null;
        }

        /// <summary>
        /// Gets request statistics
        /// </summary>
        public Dictionary<string, int> GetRequestStatistics()
        {
            var stats = new Dictionary<string, int>
            {
                { "Total Requests", GetRequestsSortedByDate().Count },
                { "Tree Height", GetTreeHeight() }
            };

            foreach (var category in categoryIndex.Keys)
            {
                stats[$"Category: {category}"] = categoryIndex[category].Count;
            }

            return stats;
        }

        /// <summary>
        /// Updates a request status
        /// </summary>
        public void UpdateRequest(ServiceRequest request)
        {
            try
            {
                // Remove and reinsert in all trees
                binarySearchTree.Insert(request);
                avlTree.Insert(request);
                redBlackTree.Insert(request);

                // Update indexes
                UpdateCategoryIndex(request);
                UpdateLocationIndex(request);
                UpdateRequestVisualProperties(request);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Error updating request: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Gets filtered requests
        /// </summary>
        public List<ServiceRequest> GetFilteredRequests(string status, string category)
        {
            var allRequests = GetRequestsSortedByDate();
            return allRequests.Where(r =>
                (string.IsNullOrEmpty(status) || r.Status.Equals(status, StringComparison.OrdinalIgnoreCase)) &&
                (string.IsNullOrEmpty(category) || r.Category.Equals(category, StringComparison.OrdinalIgnoreCase)))
                .ToList();
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Updates the category index
        /// </summary>
        private void UpdateCategoryIndex(ServiceRequest request)
        {
            if (!categoryIndex.ContainsKey(request.Category))
            {
                categoryIndex[request.Category] = new List<ServiceRequest>();
            }

            if (!categoryIndex[request.Category].Contains(request))
            {
                categoryIndex[request.Category].Add(request);
            }
        }

        /// <summary>
        /// Updates the location index
        /// </summary>
        private void UpdateLocationIndex(ServiceRequest request)
        {
            if (!locationIndex.ContainsKey(request.Location))
            {
                locationIndex[request.Location] = new List<ServiceRequest>();
            }

            if (!locationIndex[request.Location].Contains(request))
            {
                locationIndex[request.Location].Add(request);
            }
        }

        /// <summary>
        /// Updates visual properties of a request
        /// </summary>
        private void UpdateRequestVisualProperties(ServiceRequest request)
        {
            var treeNode = avlTree.Search(request);
            if (treeNode != null)
            {
                request.TreeLevel = avlTree.GetHeight(treeNode);
                request.LevelPosition = GetNodePosition(treeNode);
            }
        }


        /// <summary>
        /// Gets the position of a node in its level
        /// </summary>
        private int GetNodePosition(TreeNode<ServiceRequest> node)
        {
            if (node == null) return 0;

            var currentLevel = new List<TreeNode<ServiceRequest>>();
            var queue = new Queue<TreeNode<ServiceRequest>>();
            var root = avlTree.GetRoot();
            if (root != null)
            {
                queue.Enqueue(root);
            }

            while (queue.Count > 0)
            {
                int levelSize = queue.Count;
                currentLevel.Clear();

                for (int i = 0; i < levelSize; i++)
                {
                    var current = queue.Dequeue();
                    currentLevel.Add(current);

                    if (current.Left != null) queue.Enqueue(current.Left);
                    if (current.Right != null) queue.Enqueue(current.Right);
                }

                if (currentLevel.Contains(node))
                {
                    return currentLevel.IndexOf(node);
                }
            }
            return 0;
        }
        /// <summary>
        /// Converts a tree node to a visual node
        /// </summary>
        private TreeVisualization.TreeNodeVisual ConvertToVisual(TreeNode<ServiceRequest> node, int level, int position)
        {
            if (node == null) return null;

            var visual = new TreeVisualization.TreeNodeVisual
            {
                Data = node.Data,
                Level = level,
                X = position * 100, // Basic horizontal spacing
                Y = level * 60     // Basic vertical spacing
            };

            if (node.Left != null)
            {
                visual.Left = ConvertToVisual(node.Left, level + 1, position * 2);
            }

            if (node.Right != null)
            {
                visual.Right = ConvertToVisual(node.Right, level + 1, position * 2 + 1);
            }

            return visual;
        }

        #endregion
    }
}
