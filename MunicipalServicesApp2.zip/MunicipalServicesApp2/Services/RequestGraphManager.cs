﻿
using System;
using System.Collections.Generic;
using System.Linq;
using MunicipalServicesApp2.Models;
using MunicipalServicesApp2.Utilities;

namespace MunicipalServicesApp2.Services
{
    public class RequestGraphManager
    {
        #region Private Fields
        private readonly RequestGraph requestGraph;
        private readonly RequestHeap priorityQueue;
        private readonly Dictionary<string, HashSet<int>> locationIndex;
        private readonly Dictionary<DateTime, List<int>> dateIndex;
        private readonly GraphVisualization graphVisualization;
        #endregion

        #region Constructor
        public RequestGraphManager()
        {
            requestGraph = new RequestGraph();
            priorityQueue = new RequestHeap();
            locationIndex = new Dictionary<string, HashSet<int>>();
            dateIndex = new Dictionary<DateTime, List<int>>();
            graphVisualization = new GraphVisualization(800, 450);
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Gets visualization data for the graph
        /// </summary>
        public (List<GraphVisualization.Node> Nodes, List<GraphVisualization.Edge> Edges) GetVisualizationData()
        {
            try
            {
                var nodes = requestGraph.GetVisualizationNodes();
                var edges = requestGraph.GetVisualizationEdges();
                graphVisualization.CalculateForceDirectedLayout(nodes, edges);
                return (nodes, edges);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Error getting visualization data", ex);
            }
        }

        /// <summary>
        /// Adds a new service request to the system
        /// </summary>
        public void AddRequest(ServiceRequest request)
        {
            try
            {
                requestGraph.AddRequest(request);
                priorityQueue.Insert(request);
                UpdateIndexes(request);
                ConnectRelatedRequests(request);
                UpdateVisualization();
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Error adding request: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Gets the graph density
        /// </summary>
        public double GetGraphDensity()
        {
            return requestGraph.CalculateDensity();
        }

        /// <summary>
        /// Gets the highest priority request
        /// </summary>
        public ServiceRequest GetHighestPriorityRequest()
        {
            return priorityQueue.Peek();
        }

        /// <summary>
        /// Gets all related requests for a given request
        /// </summary>
        public List<ServiceRequest> GetRelatedRequests(int requestId)
        {
            return requestGraph.GetRelatedRequests(requestId);
        }

        /// <summary>
        /// Gets requests by location
        /// </summary>
        public List<ServiceRequest> GetRequestsByLocation(string location)
        {
            if (string.IsNullOrEmpty(location) || !locationIndex.ContainsKey(location))
                return new List<ServiceRequest>();

            return requestGraph.GetAllRequestsInPriorityOrder()
                .Where(r => r.Location.Equals(location, StringComparison.OrdinalIgnoreCase))
                .ToList();
        }

        /// <summary>
        /// Gets requests by date range
        /// </summary>
        public List<ServiceRequest> GetRequestsByDateRange(DateTime startDate, DateTime endDate)
        {
            var result = new List<ServiceRequest>();
            var currentDate = startDate.Date;

            while (currentDate <= endDate.Date)
            {
                if (dateIndex.ContainsKey(currentDate))
                {
                    foreach (var requestId in dateIndex[currentDate])
                    {
                        var relatedRequests = GetRelatedRequests(requestId);
                        result.AddRange(relatedRequests);
                    }
                }
                currentDate = currentDate.AddDays(1);
            }

            return result.Distinct().ToList();
        }

        /// <summary>
        /// Updates the status of a request
        /// </summary>
        public void UpdateRequest(ServiceRequest request)
        {
            try
            {
                requestGraph.UpdateRequest(request);
                priorityQueue.UpdatePriority(request);
                UpdateVisualization();
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Error updating request: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Gets requests sorted by priority
        /// </summary>
        public List<ServiceRequest> GetRequestsByPriority()
        {
            return priorityQueue.GetAllRequestsSorted();
        }

        /// <summary>
        /// Gets requests grouped by location
        /// </summary>
        public Dictionary<string, List<ServiceRequest>> GetRequestsByLocationGroups()
        {
            return locationIndex.ToDictionary(
                kvp => kvp.Key,
                kvp => GetRequestsByLocation(kvp.Key));
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Updates indexes for a new request
        /// </summary>
        private void UpdateIndexes(ServiceRequest request)
        {
            // Update location index
            if (!locationIndex.ContainsKey(request.Location))
            {
                locationIndex[request.Location] = new HashSet<int>();
            }
            locationIndex[request.Location].Add(request.Id);

            // Update date index
            var dateKey = request.RequestDate.Date;
            if (!dateIndex.ContainsKey(dateKey))
            {
                dateIndex[dateKey] = new List<int>();
            }
            dateIndex[dateKey].Add(request.Id);
        }

        /// <summary>
        /// Connects related requests based on various criteria
        /// </summary>
        private void ConnectRelatedRequests(ServiceRequest request)
        {
            // Connect by location
            if (locationIndex.ContainsKey(request.Location))
            {
                foreach (var relatedId in locationIndex[request.Location])
                {
                    if (relatedId != request.Id)
                    {
                        requestGraph.AddConnection(request.Id, relatedId);
                    }
                }
            }

            // Connect by date proximity (within 7 days)
            var requestDate = request.RequestDate.Date;
            for (int i = -7; i <= 7; i++)
            {
                var checkDate = requestDate.AddDays(i);
                if (dateIndex.ContainsKey(checkDate))
                {
                    foreach (var relatedId in dateIndex[checkDate])
                    {
                        if (relatedId != request.Id)
                        {
                            requestGraph.AddConnection(request.Id, relatedId);
                        }
                    }
                }
            }
        }
        /// <summary>
        /// Updates the status of a request
        /// </summary>
        public void UpdateRequestStatus(ServiceRequest request, string newStatus)
        {
            try
            {
                request.UpdateStatus(newStatus);
                requestGraph.UpdateRequest(request);
                priorityQueue.UpdatePriority(request);
                UpdateVisualization();
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Error updating request status: {ex.Message}", ex);
            }
        }
        /// <summary>
        /// Updates the visualization layout
        /// </summary>
        private void UpdateVisualization()
        {
            var nodes = requestGraph.GetVisualizationNodes();
            var edges = requestGraph.GetVisualizationEdges();
            graphVisualization.CalculateForceDirectedLayout(nodes, edges);
        }
        #endregion
    }
}
