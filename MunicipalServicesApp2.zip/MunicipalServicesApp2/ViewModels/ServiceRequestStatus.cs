﻿
using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Windows.Input;
using System.Linq;
using MunicipalServicesApp2.Models;
using MunicipalServicesApp2.Services;
using MunicipalServicesApp2.Commands;
using MunicipalServicesApp2.Utilities;

namespace MunicipalServicesApp2.ViewModels
{
    /// <summary>
    /// ViewModel for the Service Request Status window
    /// </summary>
    public class ServiceRequestStatusViewModel : ViewModelBase
    {
        #region Private Fields
        private readonly ServiceRequestManager _serviceRequestManager;
        private readonly INavigationService _navigationService;
        private readonly RequestTreeManager _requestTreeManager;
        private readonly RequestGraphManager _requestGraphManager;
        private ObservableCollection<ServiceRequest> _serviceRequests;
        private ServiceRequest _selectedRequest;
        private string _selectedCategory;
        private string _selectedStatus;
        private string _searchText;
        private Dictionary<string, int> _requestStatistics;
        private string _newStatus;
        private TreeVisualization.TreeNodeVisual _treeRoot;
        private ObservableCollection<GraphVisualization.Node> _graphNodes;
        private ObservableCollection<GraphVisualization.Edge> _graphEdges;
        private Dictionary<string, string> _metrics;
        private ICommand _backCommand;
        private ICommand _updateStatusCommand;
        private ICommand _refreshCommand;
        private ICommand _sortByPriorityCommand;
        #endregion

        #region Events
        public event EventHandler VisualizationUpdated;
        #endregion

        #region Public Properties
        /// <summary>
        /// Collection of all service requests
        /// </summary>
        public ObservableCollection<ServiceRequest> ServiceRequests
        {
            get => _serviceRequests;
            set
            {
                _serviceRequests = value;
                OnPropertyChanged(nameof(ServiceRequests));
            }
        }

        /// <summary>
        /// Currently selected service request
        /// </summary>
        public ServiceRequest SelectedRequest
        {
            get => _selectedRequest;
            set
            {
                _selectedRequest = value;
                OnPropertyChanged(nameof(SelectedRequest));
                LoadRelatedRequests();
            }
        }

        /// <summary>
        /// Collection of related requests to the selected request
        /// </summary>
        public ObservableCollection<ServiceRequest> RelatedRequests { get; private set; }

        /// <summary>
        /// Available request categories
        /// </summary>
        public ObservableCollection<string> Categories { get; private set; }

        /// <summary>
        /// Selected category filter
        /// </summary>
        public string SelectedCategory
        {
            get => _selectedCategory;
            set
            {
                _selectedCategory = value;
                OnPropertyChanged(nameof(SelectedCategory));
                ApplyFilters();
            }
        }

        /// <summary>
        /// Available request statuses
        /// </summary>
        public ObservableCollection<string> Statuses { get; } = new ObservableCollection<string>
        {
            "All",
            "Pending",
            "In Progress",
            "Completed"
        };

        /// <summary>
        /// Selected status filter
        /// </summary>
        public string SelectedStatus
        {
            get => _selectedStatus;
            set
            {
                _selectedStatus = value;
                OnPropertyChanged(nameof(SelectedStatus));
                ApplyFilters();
            }
        }

        /// <summary>
        /// Search text for filtering requests
        /// </summary>
        public string SearchText
        {
            get => _searchText;
            set
            {
                _searchText = value;
                OnPropertyChanged(nameof(SearchText));
                ApplyFilters();
            }
        }

        /// <summary>
        /// Statistics about service requests
        /// </summary>
        public Dictionary<string, int> RequestStatistics
        {
            get => _requestStatistics;
            set
            {
                _requestStatistics = value;
                OnPropertyChanged(nameof(RequestStatistics));
            }
        }

        public string NewStatus
        {
            get => _newStatus;
            set
            {
                _newStatus = value;
                OnPropertyChanged(nameof(NewStatus));
            }
        }

        public TreeVisualization.TreeNodeVisual TreeRoot
        {
            get => _treeRoot;
            set
            {
                _treeRoot = value;
                OnPropertyChanged(nameof(TreeRoot));
            }
        }

        public ObservableCollection<GraphVisualization.Node> GraphNodes
        {
            get => _graphNodes;
            set
            {
                _graphNodes = value;
                OnPropertyChanged(nameof(GraphNodes));
            }
        }

        public ObservableCollection<GraphVisualization.Edge> GraphEdges
        {
            get => _graphEdges;
            set
            {
                _graphEdges = value;
                OnPropertyChanged(nameof(GraphEdges));
            }
        }

        public Dictionary<string, string> Metrics
        {
            get => _metrics;
            set
            {
                _metrics = value;
                OnPropertyChanged(nameof(Metrics));
            }
        }
        #endregion

        #region Commands
        public ICommand BackCommand
        {
            get
            {
                return _backCommand ?? (_backCommand = new RelayCommand(
                    param => NavigateBack()
                ));
            }
        }

        public ICommand UpdateStatusCommand
        {
            get
            {
                return _updateStatusCommand ?? (_updateStatusCommand = new RelayCommand(
                    param => UpdateRequestStatus(param as string),
                    param => SelectedRequest != null
                ));
            }
        }

        public ICommand RefreshCommand
        {
            get
            {
                return _refreshCommand ?? (_refreshCommand = new RelayCommand(
                    param => RefreshData()
                ));
            }
        }

        public ICommand SortByPriorityCommand
        {
            get
            {
                return _sortByPriorityCommand ?? (_sortByPriorityCommand = new RelayCommand(
                    param => SortByPriority()
                ));
            }
        }
        #endregion

        #region Constructors
        public ServiceRequestStatusViewModel(
            ServiceRequestManager serviceRequestManager,
            INavigationService navigationService)
        {
            _serviceRequestManager = serviceRequestManager;
            _navigationService = navigationService;
            Initialize();
        }

        public ServiceRequestStatusViewModel(
            ServiceRequestManager serviceRequestManager,
            INavigationService navigationService,
            RequestTreeManager requestTreeManager,
            RequestGraphManager requestGraphManager)
        {
            _serviceRequestManager = serviceRequestManager;
            _navigationService = navigationService;
            _requestTreeManager = requestTreeManager;
            _requestGraphManager = requestGraphManager;
            Initialize();
            UpdateVisualizations(); // Make sure to call this

        }
        #endregion

        #region Private Methods
        private void Initialize()
        {
            GraphNodes = new ObservableCollection<GraphVisualization.Node>();
            GraphEdges = new ObservableCollection<GraphVisualization.Edge>();
            Metrics = new Dictionary<string, string>();
            RelatedRequests = new ObservableCollection<ServiceRequest>();

            LoadServiceRequests();
            LoadCategories();
            LoadStatistics();
            InitializeVisualizations();
        }

        private void LoadServiceRequests()
        {
            ServiceRequests = new ObservableCollection<ServiceRequest>(_serviceRequestManager.GetAllServiceRequests());
            RelatedRequests = new ObservableCollection<ServiceRequest>();
            UpdateVisualizations();
        }

        private void LoadCategories()
        {
            var categories = _serviceRequestManager.GetRequestsByCategory().Keys.ToList();
            categories.Insert(0, "All");
            Categories = new ObservableCollection<string>(categories);
        }

        private void LoadStatistics()
        {
            RequestStatistics = _serviceRequestManager.GetRequestStatistics();
            UpdateMetrics();
        }

        private void LoadRelatedRequests()
        {
            if (SelectedRequest != null)
            {
                var related = _serviceRequestManager.GetRelatedRequests(SelectedRequest.Id);
                RelatedRequests = new ObservableCollection<ServiceRequest>(related);
                OnPropertyChanged(nameof(RelatedRequests));
                UpdateVisualizations();
            }
        }

        private void InitializeVisualizations()
        {
            if (_requestTreeManager != null)
            {
                TreeRoot = _requestTreeManager.GetVisualizationTree();
            }

            if (_requestGraphManager != null)
            {
                var graphData = _requestGraphManager.GetVisualizationData();
                GraphNodes = new ObservableCollection<GraphVisualization.Node>(graphData.Nodes);
                GraphEdges = new ObservableCollection<GraphVisualization.Edge>(graphData.Edges);
            }

            UpdateMetrics();
            VisualizationUpdated?.Invoke(this, EventArgs.Empty);
        }

        private void UpdateVisualizations()
        {
            try
            {
                if (_requestTreeManager != null)
                {
                    TreeRoot = _requestTreeManager.GetVisualizationTree();
                    System.Diagnostics.Debug.WriteLine($"Tree Data: {TreeRoot != null}");
                }
                else
                {
                    System.Diagnostics.Debug.WriteLine("Tree Manager is null");
                }

                if (_requestGraphManager != null)
                {
                    var graphData = _requestGraphManager.GetVisualizationData();
                    GraphNodes = new ObservableCollection<GraphVisualization.Node>(graphData.Nodes);
                    GraphEdges = new ObservableCollection<GraphVisualization.Edge>(graphData.Edges);
                    System.Diagnostics.Debug.WriteLine($"Graph Data - Nodes: {GraphNodes?.Count}, Edges: {GraphEdges?.Count}");
                }
                else
                {
                    System.Diagnostics.Debug.WriteLine("Graph Manager is null");
                }

                VisualizationUpdated?.Invoke(this, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Visualization Error: {ex.Message}");
            }
        }


        private void UpdateMetrics()
        {
            Metrics = new Dictionary<string, string>
            {
                { "Tree Height", _requestTreeManager?.GetTreeHeight().ToString() ?? "0" },
                { "Graph Density", _requestGraphManager?.GetGraphDensity().ToString("F2") ?? "0.00" },
                { "Total Nodes", ServiceRequests?.Count.ToString() ?? "0" }
            };
        }

        private void ApplyFilters()
        {
            var filteredRequests = _serviceRequestManager.GetFilteredRequests(
                SelectedStatus == "All" ? null : SelectedStatus,
                SelectedCategory == "All" ? null : SelectedCategory
            );

            if (!string.IsNullOrWhiteSpace(SearchText))
            {
                filteredRequests = filteredRequests.Where(r =>
                    r.Title.IndexOf(SearchText, StringComparison.OrdinalIgnoreCase) >= 0 ||
                    r.Description.IndexOf(SearchText, StringComparison.OrdinalIgnoreCase) >= 0
                ).ToList();
            }

            ServiceRequests = new ObservableCollection<ServiceRequest>(filteredRequests);
            UpdateVisualizations();
        }

        private void UpdateRequestStatus(string newStatus)
        {
            if (SelectedRequest != null)
            {
                _serviceRequestManager.UpdateRequestStatus(SelectedRequest.Id, newStatus);
                RefreshData();
            }
        }

        private void RefreshData()
        {
            LoadServiceRequests();
            LoadStatistics();
            ApplyFilters();
            UpdateVisualizations();
        }

        private void SortByPriority()
        {
            var priorityRequests = _serviceRequestManager.GetRequestsByPriority();
            ServiceRequests = new ObservableCollection<ServiceRequest>(priorityRequests);
            UpdateVisualizations();
        }

        private void NavigateBack()
        {
            _navigationService.NavigateTo("MainMenu");
        }
        #endregion
    }
}
