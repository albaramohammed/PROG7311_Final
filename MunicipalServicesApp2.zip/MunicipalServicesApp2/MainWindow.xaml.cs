﻿using System.Windows;
using System.Windows.Controls;
using MunicipalServicesApp2.Services;

namespace MunicipalServicesApp2
{
    public partial class MainWindow : Window
    {
        private INavigationService _navigationService;

        public MainWindow()
        {
            InitializeComponent();
        }

        public void InitializeServices(
            MunicipalServicesApp2.Services.EventManager eventManager,
            AnnouncementManager announcementManager,
            IssueManager issueManager,
            UserEngagementService userEngagementService,
            SearchEngine searchEngine,
            ServiceRequestManager serviceRequestManager)
        {
            // Create instances of the new managers
            var requestTreeManager = new RequestTreeManager();
            var requestGraphManager = new RequestGraphManager();

            // Initialize navigation service with all required dependencies
            _navigationService = new NavigationService(
                MainFrame,
                eventManager,
                announcementManager,
                issueManager,
                userEngagementService,
                searchEngine,
                serviceRequestManager,
                requestTreeManager,
                requestGraphManager
            );
        }

        public void NavigateToMainMenu()
        {
            _navigationService.NavigateTo("MainMenu");
        }
    }
}