﻿using System;

namespace MunicipalServicesApp2.Models
{
    public class Issue
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Location { get; set; }
        public string Category { get; set; }
        public string Description { get; set; }
        public DateTime ReportDate { get; set; }
        public string Status { get; set; }

        public Issue(int id, string title, string location, string category, string description)
        {
            Id = id;
            Title = title;
            Location = location;
            Category = category;
            Description = description;
            ReportDate = DateTime.Now;
            Status = "Pending";
        }
    }
}