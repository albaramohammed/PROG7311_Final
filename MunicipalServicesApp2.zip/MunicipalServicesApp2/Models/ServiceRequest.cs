﻿
using System;
using System.Collections.Generic;

namespace MunicipalServicesApp2.Models
{
    /// <summary>
    /// Represents a service request in the municipal services system
    /// </summary>
    public class ServiceRequest : IComparable<ServiceRequest>
    {
        #region Basic Properties

        /// <summary>
        /// Unique identifier for the service request
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Title of the service request
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// Current status of the request (e.g., Pending, In Progress, Completed)
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// Date and time when the request was submitted
        /// </summary>
        public DateTime RequestDate { get; set; }

        /// <summary>
        /// Detailed description of the service request
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Category of the service request (e.g., Roads, Water, Electricity)
        /// </summary>
        public string Category { get; set; }

        /// <summary>
        /// Physical location where the service is needed
        /// </summary>
        public string Location { get; set; }

        /// <summary>
        /// Priority level of the request (e.g., High, Medium, Low)
        /// </summary>
        public string Priority { get; set; }

        /// <summary>
        /// Tracks the last update time of the request
        /// </summary>
        public DateTime LastUpdated { get; set; }

        #endregion

        #region Visualization Properties

        /// <summary>
        /// List of related request IDs for visualization
        /// </summary>
        public List<int> RelatedRequestIds { get; set; } = new List<int>();

        /// <summary>
        /// X coordinate for visualization
        /// </summary>
        public double VisualX { get; set; }

        /// <summary>
        /// Y coordinate for visualization
        /// </summary>
        public double VisualY { get; set; }

        /// <summary>
        /// Color code for visual representation
        /// </summary>
        public string VisualColor { get; private set; }

        /// <summary>
        /// Level in the tree visualization
        /// </summary>
        public int TreeLevel { get; set; }

        /// <summary>
        /// Position index within its level
        /// </summary>
        public int LevelPosition { get; set; }

        #endregion

        #region Constructors

        /// <summary>
        /// Parameterized constructor for creating a new service request
        /// </summary>
        public ServiceRequest(int id, string title, string status, DateTime requestDate,
            string description, string category, string location = "", string priority = "Medium")
        {
            Id = id;
            Title = title;
            Status = status;
            RequestDate = requestDate;
            Description = description;
            Category = category;
            Location = location;
            Priority = priority;
            LastUpdated = DateTime.Now;
            RelatedRequestIds = new List<int>();
            UpdateVisualColor();
        }

        /// <summary>
        /// Default constructor
        /// </summary>
        public ServiceRequest()
        {
            RequestDate = DateTime.Now;
            Status = "Pending";
            Priority = "Medium";
            LastUpdated = DateTime.Now;
            RelatedRequestIds = new List<int>();
            UpdateVisualColor();
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Updates the status of the request and sets the LastUpdated time
        /// </summary>
        public void UpdateStatus(string newStatus)
        {
            Status = newStatus;
            LastUpdated = DateTime.Now;
            UpdateVisualColor();
        }

        /// <summary>
        /// Updates the priority of the request
        /// </summary>
        public void UpdatePriority(string newPriority)
        {
            Priority = newPriority;
            LastUpdated = DateTime.Now;
            UpdateVisualColor();
        }

        /// <summary>
        /// Adds a related request ID
        /// </summary>
        public void AddRelatedRequest(int requestId)
        {
            if (!RelatedRequestIds.Contains(requestId))
            {
                RelatedRequestIds.Add(requestId);
            }
        }

        /// <summary>
        /// Returns a formatted string representation of the service request
        /// </summary>
        public override string ToString()
        {
            return $"{Id} - {Title} ({Status}) - {Category} - {RequestDate.ToShortDateString()}";
        }

        /// <summary>
        /// Implements IComparable to allow sorting of service requests
        /// </summary>
        public int CompareTo(ServiceRequest other)
        {
            if (other == null) return 1;

            int priorityComparison = ComparePriority(this.Priority, other.Priority);
            if (priorityComparison != 0) return priorityComparison;

            return this.RequestDate.CompareTo(other.RequestDate);
        }

        /// <summary>
        /// Creates a copy of the current service request
        /// </summary>
        public ServiceRequest Clone()
        {
            return new ServiceRequest
            {
                Id = this.Id,
                Title = this.Title,
                Status = this.Status,
                RequestDate = this.RequestDate,
                Description = this.Description,
                Category = this.Category,
                Location = this.Location,
                Priority = this.Priority,
                LastUpdated = this.LastUpdated,
                RelatedRequestIds = new List<int>(this.RelatedRequestIds),
                VisualX = this.VisualX,
                VisualY = this.VisualY,
                VisualColor = this.VisualColor,
                TreeLevel = this.TreeLevel,
                LevelPosition = this.LevelPosition
            };
        }

        /// <summary>
        /// Determines if a request is considered urgent
        /// </summary>
        public bool IsUrgent()
        {
            TimeSpan age = DateTime.Now - RequestDate;
            return Priority.ToLower() == "urgent" ||
                   (Priority.ToLower() == "high" && age.TotalDays > 3);
        }

        /// <summary>
        /// Gets the age of the request in days
        /// </summary>
        public int GetAge()
        {
            return (int)(DateTime.Now - RequestDate).TotalDays;
        }

        /// <summary>
        /// Determines if this request is related to another request
        /// </summary>
        public bool IsRelatedTo(ServiceRequest other)
        {
            if (other == null) return false;

            // Check for relationship based on various criteria
            return Category == other.Category ||
                   Location == other.Location ||
                   Math.Abs((RequestDate - other.RequestDate).TotalDays) <= 7 ||
                   RelatedRequestIds.Contains(other.Id);
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Helper method to compare priority levels
        /// </summary>
        private int ComparePriority(string priority1, string priority2)
        {
            return GetPriorityValue(priority1).CompareTo(GetPriorityValue(priority2));
        }

        /// <summary>
        /// Helper method to convert priority string to numeric value
        /// </summary>
        private int GetPriorityValue(string priority)
        {
            string lowerPriority = priority.ToLower();
            switch (lowerPriority)
            {
                case "urgent": return 3;
                case "high": return 2;
                case "medium": return 1;
                case "low": return 0;
                default: return -1;
            }
        }

        /// <summary>
        /// Updates the visual color based on status and priority
        /// </summary>
        /// <summary>
        /// Updates the visual color based on status and priority
        /// </summary>
        private void UpdateVisualColor()
        {
            var statusLower = Status.ToLower();

            if (statusLower == "completed")
            {
                VisualColor = "#4CAF50";  // Green
            }
            else if (statusLower == "in progress")
            {
                VisualColor = "#FFA500";  // Orange
            }
            else if (statusLower == "pending")
            {
                VisualColor = IsUrgent() ? "#FF0000" : "#F44336";  // Red (brighter for urgent)
            }
            else
            {
                VisualColor = "#9E9E9E";  // Gray for unknown status
            }
        }

        #endregion
    }
}
