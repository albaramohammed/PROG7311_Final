﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MunicipalServicesApp2.Models
{
    public class MediaAttachment
    {
        public int Id { get; set; }
        public string FileName { get; set; }
        public byte[] FileData { get; set; }
        public string FileType { get; set; }

        public MediaAttachment(int id, string fileName, byte[] fileData, string fileType)
        {
            Id = id;
            FileName = fileName;
            FileData = fileData;
            FileType = fileType;
        }

        public string GetFileInfo()
        {
            return $"{FileName} ({FileType})";
        }
    }
}

