﻿using System;
using System.Collections.Generic;

namespace MunicipalServicesApp2.Models
{
    public class Announcement
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public DateTime Date { get; set; }
        public string Content { get; set; }

        public Announcement(int id, string title, DateTime date, string content)
        {
            Id = id;
            Title = title;
            Date = date;
            Content = content;
        }

        public string GetFormattedAnnouncement()
        {
            return $"{Date.ToShortDateString()}: {Title}\n{Content}";
        }
    }
}